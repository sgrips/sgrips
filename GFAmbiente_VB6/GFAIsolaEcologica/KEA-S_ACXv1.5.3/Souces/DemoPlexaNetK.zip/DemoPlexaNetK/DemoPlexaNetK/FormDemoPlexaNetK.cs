using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace DemoPlexaNetK
{

    public partial class FormDemoPlexaNetK : Form
    {
        Boolean riga1;
        Boolean FlagMethod;
        DateTime OraCorrente = DateTime.Now;
        FileVersionInfo myFI;
        string initExePath = Path.GetFullPath(".\\");
        string LogString;
        private FunctionDemoPlexaNetK AuxFunction = new FunctionDemoPlexaNetK();

        public FormDemoPlexaNetK()
        {
            myFI = FileVersionInfo.GetVersionInfo(initExePath + "\\DemoPlexaNetK.exe");
            InitializeComponent();
            this.Size = this.GetPreferredSize(this.Size);
        }

        private void EnableGroupBox()
        {
            groupBoxKEInterface.Enabled = false;
            groupBoxTamper.Enabled = true;
            groupBoxDisplay.Enabled = true;
            groupBoxInfoK.Enabled = true;
            groupBoxLed_Buzzer.Enabled = true;
            groupBoxPulser.Enabled = true;
            groupBoxKeyEnter.Enabled = true;
            groupBoxDigitalLevel.Enabled = true;
            groupBoxCodeComp.Enabled = true;
            groupBoxCode.Enabled = true;
            groupBoxParameters.Enabled = true;
        }

        private void DisableGroupBox()
        {
            groupBoxKEInterface.Enabled = true;
            groupBoxTamper.Enabled = false;
            groupBoxDisplay.Enabled = false;
            groupBoxInfoK.Enabled = false;
            groupBoxLed_Buzzer.Enabled = false;
            groupBoxPulser.Enabled = false;
            groupBoxKeyEnter.Enabled = false;
            groupBoxDigitalLevel.Enabled = false;
            groupBoxCodeComp.Enabled = false;
            groupBoxCode.Enabled = false;
            groupBoxParameters.Enabled = false;
        }

        private void EnablePictureLedK()
        {
            pictureBoxLedAux.Enabled = true;
            pictureBoxLedFbk.Enabled = true;
            pictureBoxLedRdy.Enabled = true;
            pictureBoxLedOk.Enabled = true;
        }

        private void DisablePictureLedK()
        {
            pictureBoxLedAux.Enabled = false;
            pictureBoxLedFbk.Enabled = false;
            pictureBoxLedRdy.Enabled = false;
            pictureBoxLedOk.Enabled = false;
        }

        private void DisablePictureLedAck()
        {
            pictureBoxOnCodeEnter.Visible = false;
            pictureBoxOnDigitalLevel.Visible = false;
            pictureBoxOnDisplayRead.Visible = false;
            pictureBoxOnDisplayUpdate.Visible = false;
            pictureBoxOnPulserRead.Visible = false;
            pictureBoxOnPulserUpdate.Visible = false;
            pictureBoxOnUpdateLed_Buzzer.Visible = false;
            pictureBoxOnCodeComp.Visible = false;
            pictureBoxOnCodeUpdate.Visible = false;
            pictureBoxOnParameters.Visible = false;
            pictureBoxOnKeyEnter.Visible = false;
            pictureBoxOnTamperChange.Visible = false;
            labelOnPulserSent.Enabled = false;
            labelOnDisplaySent.Enabled = false;
            labelOnLedAndBuzzerSent.Enabled = false;
            labelOnCodeSent.Enabled = false;
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            if (axPlexaNetKX1.Connected == false)
            {
                if (radioButtonPort.Checked == true)
                {
                    try
                    {
                        axPlexaNetKX1.Port = comboBoxCOM.SelectedItem.ToString();
                        axPlexaNetKX1.AcknowledgedMode = checkBoxAcknowledge.Checked;
                        if (checkBoxVerbose.Checked == true)
                        {
                            LogString = " Connect Method " + comboBoxCOM.SelectedItem.ToString()
                                + " Acknowledge Mode " + Convert.ToString(axPlexaNetKX1.AcknowledgedMode)
                                + "\r\n";
                            textBoxVerbose.AppendText(LogString);
                            AuxFunction.Log(LogString);
                        }
                        axPlexaNetKX1.Connect();
                    }
                    catch (NullReferenceException)
                    {
                        LogString = " Selezionare COM "
                            + "\r\n";
                        textBoxVerbose.AppendText(LogString);
                    }
                }
                if (radioButtonServer.Checked == true)
                {
                    axPlexaNetKX1.Server = textBoxIP.Text;
                    axPlexaNetKX1.AcknowledgedMode = checkBoxAcknowledge.Checked;
                    axPlexaNetKX1.Connect();
                    if (checkBoxVerbose.Checked == true)
                    {
                        LogString = " Connect Method " + textBoxIP.Text
                            + " Acknowledge Mode " + Convert.ToString(axPlexaNetKX1.AcknowledgedMode)
                            + "\r\n";
                        textBoxVerbose.AppendText(LogString);
                        AuxFunction.Log(LogString);
                    }
                }
            }
        }

        private void radioButtonPort_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonPort.Checked == true)
            {
                comboBoxCOM.Enabled = true;
                textBoxIP.Enabled = false;
            }
        }

        private void radioButtonServer_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonServer.Checked == true)
            {
                comboBoxCOM.Enabled = false;
                textBoxIP.Enabled = true;
            }
        }

        private void axPlexaNetKX1_OnConnect(object sender, EventArgs e)
        {
            timerOnAcknoledgeLed.Enabled = true;
            pictureBoxConnect.Visible = true;
            pictureBoxDisconnect.Visible = false;
            EnableGroupBox();
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " On Connect Event "
                    + axPlexaNetKX1.Port
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void buttonDisconnect_Click(object sender, EventArgs e)
        {
            axPlexaNetKX1.Disconnect();
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " Disconnect Method " + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnDisconnect(object sender, EventArgs e)
        {
            pictureBoxConnect.Visible = false;
            pictureBoxDisconnect.Visible = true;

            DisableGroupBox();
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnDisconnect Event "
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void buttonUpdatePulser_Click(object sender, EventArgs e)
        {
            try
            {
                FlagMethod = axPlexaNetKX1.UpdatePulser(Convert.ToInt16(
                    numericUpDownAddressPulser.Value),
                    Convert.ToInt16(numericUpDownResourcePulser.Value),
                    Convert.ToInt16(numericUpDownValuePulser.Value),
                    Convert.ToInt16(numericUpDownIntervalPulser.Value),
                    Convert.ToInt16(numericUpDownCountPulser.Value));
            }
            catch (Exception)
            {
            }
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " UpdatePulser Method "
                    + " : Flag " + Convert.ToString(FlagMethod)
                    + "\r\n"
                    + " Indirizzo " + Convert.ToString(numericUpDownAddressPulser.Value)
                    + " Rele' # " + Convert.ToString(numericUpDownResourcePulser.Value)
                    + " Valore " + Convert.ToString(numericUpDownValuePulser.Value)
                    + " Commutazioni " + Convert.ToString(numericUpDownCountPulser.Value)
                    + " Intervallo " + Convert.ToString(numericUpDownIntervalPulser.Value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnPulserUpdate(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnPulserUpdateEvent e)
        {
            pictureBoxOnPulserUpdate.Visible = true;
            timerOnAcknoledgeLed.Start();
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnPulserUpdate Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Rele' # " + Convert.ToString(e.resource)
                    + " Valore " + Convert.ToString(e.value)
                    + " Commutazioni " + Convert.ToString(e.count)
                    + " Intervallo " + Convert.ToString(e.interval)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnPulserSent(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnPulserSentEvent e)
        {
            labelOnPulserSent.Enabled = true;
            timerOnAcknoledgeLed.Start();
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnPulserSent Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Rele' # " + Convert.ToString(e.resource)
                    + " Valore " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnCodeEnter(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnCodeEnterEvent e)
        {
            pictureBoxOnCodeEnter.Visible = true;
            timerOnAcknoledgeLed.Start();
            textBoxValueK.Text = e.value;
            textBoxCodeValue.Text = e.value;
            textBoxTecnologyK.Text = AuxFunction.IndiceTecnologia(e.technology);
            textBoxResourceK.Text = AuxFunction.IndiceRisorsa(e.resource);
            textBoxAddressK.Text = Convert.ToString(e.address);

            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnCodeEnter Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Risorsa " + AuxFunction.IndiceRisorsa(e.resource)
                    + " Tecnologia " + AuxFunction.IndiceTecnologia(e.technology)
                    + " Valore " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void buttonPulserRead_Click(object sender, EventArgs e)
        {
            FlagMethod = axPlexaNetKX1.ReadPulser(Convert.ToInt16(numericUpDownAddressPulser.Value), Convert.ToInt16(numericUpDownResourcePulser.Value));
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " PulserRead Method "
                    + " : Flag " + Convert.ToString(FlagMethod)
                    + "\r\n"
                    + "Indirizzo " + Convert.ToString(numericUpDownAddressPulser.Value)
                    + " Rele' # " + Convert.ToString(numericUpDownResourcePulser.Value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnPulserRead(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnPulserReadEvent e)
        {
            pictureBoxOnPulserRead.Visible = true;
            timerOnAcknoledgeLed.Start();
            numericUpDownValuePulser.Value = Convert.ToInt16(e.value);
            numericUpDownResourcePulser.Value = Convert.ToInt16(e.resource);
            numericUpDownAddressPulser.Value = Convert.ToInt16(e.address);
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnPulserRead Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Rele' # " + Convert.ToString(e.resource)
                    + " Valore Rele' " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void buttonUpdateLed_Click(object sender, EventArgs e)
        {
            int ValueRdy, ValueAux, ValueFbk, ValueOk,
                IntervalRdy, IntervalAux, IntervalFbk, IntervalOk,
                CountRdy, CountAux, CountFbk, CountOk;
            if (checkBoxRdy.Checked)
            {
                ValueRdy = 1;
                IntervalRdy = Convert.ToInt16(numericUpDownIntervalLedRdy.Value);
                CountRdy = Convert.ToInt16(numericUpDownCountLedRdy.Value);
            }
            else
            {
                ValueRdy = 0;
                IntervalRdy = 0;
                CountRdy = 0;
            }
            if (checkBoxAux.Checked)
            {
                ValueAux = 1;
                IntervalAux = Convert.ToInt16(numericUpDownIntervalLedAux.Value);
                CountAux = Convert.ToInt16(numericUpDownCountLedAux.Value);
            }
            else
            {
                ValueAux = 0;
                IntervalAux = 0;
                CountAux = 0;
            }
            if (checkBoxFbk.Checked)
            {
                ValueFbk = 1;
                IntervalFbk = Convert.ToInt16(numericUpDownIntervalLedFbk.Value);
                CountFbk = Convert.ToInt16(numericUpDownCountLedFbk.Value);
            }
            else
            {
                ValueFbk = 0;
                IntervalFbk = 0;
                CountFbk = 0;
            }
            if (checkBoxOk.Checked)
            {
                ValueOk = 1;
                IntervalOk = Convert.ToInt16(numericUpDownIntervalLedOk.Value);
                CountOk = Convert.ToInt16(numericUpDownCountLedOk.Value);
            }
            else
            {
                ValueOk = 0;
                IntervalOk = 0;
                CountOk = 0;
            }

            FlagMethod = axPlexaNetKX1.UpdateLedsAndBuzzer(
                Convert.ToInt16(numericUpDownAddressLed_Buzzer.Value), 1,
                ValueRdy, IntervalRdy, CountRdy,
                ValueAux, IntervalAux, CountAux,
                ValueFbk, IntervalFbk, CountFbk,
                ValueOk,  IntervalOk,  CountOk,
                0, 0);

            if (checkBoxVerbose.Checked == true)
            {
                LogString = " UpdateLedAndBuzzer Method "
                    + " : Flag " + Convert.ToString(FlagMethod)
                    + "\r\n" + "Indirizzo " + Convert.ToString(numericUpDownAddressLed_Buzzer.Value)
                    + " Risorsa 1 "
                    + "\r\n"
                    + " Led RDY " + Convert.ToString(ValueRdy)
                    + " Commutazioni " + Convert.ToString(IntervalRdy)
                    + " Intervallo " + Convert.ToString(CountRdy)
                    + " Led AUX " + Convert.ToString(ValueAux)
                    + " Commutazioni " + Convert.ToString(IntervalAux)
                    + " Intervallo " + Convert.ToString(CountAux)
                    + " Led FBK " + Convert.ToString(ValueFbk)
                    + " Commutazioni " + Convert.ToString(IntervalFbk)
                    + " Intervallo " + Convert.ToString(CountFbk)
                    + " Led OK " + Convert.ToString(ValueOk)
                    + " Commutazioni " + Convert.ToString(IntervalOk)
                    + " Intervallo " + Convert.ToString(CountOk)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnLedsAndBuzzerUpdate(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnLedsAndBuzzerUpdateEvent e)
        {
            pictureBoxOnUpdateLed_Buzzer.Visible = true;
            timerOnAcknoledgeLed.Start();
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnLedsAndBuzzerUpdate Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Risorsa 1 "
                    + "\r\n"
                    + " Led RDY Value " + Convert.ToString(e.valueRdy)
                    + " Commutazioni " + Convert.ToString(e.countRdy)
                    + " Intervallo " + Convert.ToString(e.intervalRdy)
                    + " Led AUX Value " + Convert.ToString(e.valueAux)
                    + " Commutazioni " + Convert.ToString(e.countAux)
                    + " Intervallo " + Convert.ToString(e.intervalAux)
                    + " Led FBK Value " + Convert.ToString(e.valueFbk)
                    + " Commutazioni " + Convert.ToString(e.countFbk)
                    + " Intervallo " + Convert.ToString(e.intervalFbk)
                    + " Led OK Value " + Convert.ToString(e.valueOk)
                    + " Commutazioni " + Convert.ToString(e.countOk)
                    + " Intervallo " + Convert.ToString(e.intervalOk)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void buttonUpdate_Buzzer_Click(object sender, EventArgs e)
        {
            FlagMethod = axPlexaNetKX1.UpdateLedsAndBuzzer(
                Convert.ToInt16(numericUpDownAddressLed_Buzzer.Value), 1,
                0, 0, 0,
                0, 0, 0,
                0, 0, 0,
                0, 0, 0,
                Convert.ToInt16(numericUpDownValueBuzzer.Value), Convert.ToInt16(numericUpDownIntervalBuzzer.Value));

            if (checkBoxVerbose.Checked == true)
            {
                LogString = " UpdateLedAndBuzzer Method "
                    + " : Flag " + Convert.ToString(FlagMethod)
                    + "\r\n"
                    + "Indirizzo " + Convert.ToString(numericUpDownAddressLed_Buzzer.Value)
                    + " Risorsa 1 "
                    + "Tono " + Convert.ToString(numericUpDownValueBuzzer.Value)
                    + " Intervallo " + Convert.ToString(numericUpDownIntervalBuzzer.Value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void buttonReadDisplay_Click(object sender, EventArgs e)
        {
            if (checkBoxRow1.Checked == true)
            {
                FlagMethod = axPlexaNetKX1.ReadDisplay(Convert.ToInt16(numericUpDownAddressDisplay.Value), 1);
                riga1 = true;

                if (checkBoxVerbose.Checked == true)
                {
                    LogString = " ReadDisplay Method "
                        + " : Flag " + Convert.ToString(FlagMethod)
                        + "\r\n"
                        + "Indirizzo " + Convert.ToString(numericUpDownAddressDisplay.Value)
                        + " Riga 1 "
                        + "\r\n";
                    textBoxVerbose.AppendText(LogString);
                    AuxFunction.Log(LogString);
                }
            }
            if (checkBoxRow2.Checked == true)
            {
                FlagMethod = axPlexaNetKX1.ReadDisplay(Convert.ToInt16(numericUpDownAddressDisplay.Value), 2);

                if (checkBoxVerbose.Checked == true)
                {
                    LogString = " ReadDisplay Method "
                        + " : Flag " + Convert.ToString(FlagMethod)
                        + "\r\n"
                        + "Indirizzo " + Convert.ToString(numericUpDownAddressDisplay.Value)
                        + " Riga 2 "
                        + "\r\n";
                    textBoxVerbose.AppendText(LogString);
                    AuxFunction.Log(LogString);
                }
            }
        }

        private void buttonUpdateDisplay_Click(object sender, EventArgs e)
        {
            if (checkBoxRow1.Checked == true)
            {
                FlagMethod = axPlexaNetKX1.UpdateDisplay(Convert.ToInt16(numericUpDownAddressDisplay.Value), 1, textBoxRow1.Text);
                if (checkBoxVerbose.Checked == true)
                {
                    LogString = " UpdateDisplay Method "
                        + " : Flag " + Convert.ToString(FlagMethod)
                        + "\r\n"
                        + "Indirizzo " + Convert.ToString(numericUpDownAddressDisplay.Value)
                        + " Riga 1 "
                        + " Testo " + textBoxRow1.Text
                        + "\r\n";
                    textBoxVerbose.AppendText(LogString);
                    AuxFunction.Log(LogString);
                }
            }
            if (checkBoxRow2.Checked == true)
            {
                FlagMethod = axPlexaNetKX1.UpdateDisplay(Convert.ToInt16(numericUpDownAddressDisplay.Value), 2, textBoxRow2.Text);
                if (checkBoxVerbose.Checked == true)
                {
                    LogString = " UpdateDisplay Method "
                        + "  : Flag " + Convert.ToString(FlagMethod)
                        + "\r\n"
                        + "Indirizzo " + Convert.ToString(numericUpDownAddressDisplay.Value)
                        + " Riga 2 "
                        + " Testo " + textBoxRow2.Text
                        + "\r\n";
                    textBoxVerbose.AppendText(LogString);
                    AuxFunction.Log(LogString);
                }
            }
        }

        private void axPlexaNetKX1_OnDisplayRead(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnDisplayReadEvent e)
        {
            pictureBoxOnDisplayRead.Visible = true;
            timerOnAcknoledgeLed.Start();
            if (riga1 == true)
            {
                textBoxRow1.Text = e.value;
                riga1 = false;
                if (checkBoxVerbose.Checked == true)
                {
                    LogString = "OnDisplayRead Event "
                        + " Indirizzo " + Convert.ToString(e.address)
                        + " Risorsa " + Convert.ToString(e.resource)
                        + " Valore " + Convert.ToString(e.value)
                        + "\r\n";
                    textBoxVerbose.AppendText(LogString);
                    AuxFunction.Log(LogString);
                }
            }
            else
            {
                textBoxRow2.Text = e.value;
                if (checkBoxVerbose.Checked == true)
                {
                    LogString = "OnDisplayRead Event "
                        + " Indirizzo " + Convert.ToString(e.address)
                        + " Risorsa " + Convert.ToString(e.resource)
                        + " Valore " + Convert.ToString(e.value)
                        + "\r\n";
                    textBoxVerbose.AppendText(LogString);
                    AuxFunction.Log(LogString);
                }
            }
        }

        private void axPlexaNetKX1_OnDisplayUpdate(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnDisplayUpdateEvent e)
        {
            pictureBoxOnDisplayUpdate.Visible = true;
            timerOnAcknoledgeLed.Start();
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnDisplayUpdate Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Riga " + Convert.ToString(e.resource)
                    + " Testo " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnKeyEnter(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnKeyEnterEvent e)
        {
            pictureBoxOnKeyEnter.Visible = true;
            timerOnAcknoledgeLed.Start();
            textBoxAddressKey.Text = Convert.ToString(e.address);
            textBoxValueKey.Text = Convert.ToString(e.value);
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnKeyEnter Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Risorsa " + Convert.ToString(e.resource)
                    + " Valore " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnTamperChange(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnTamperChangeEvent e)
        {
            pictureBoxOnTamperChange.Visible = true;
            timerOnAcknoledgeLed.Start();
            textBoxAddressTamper.Text = Convert.ToString(e.address);
            textBoxValueTamper.Text = Convert.ToString(e.value);
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnTamperChange Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Risorsa " + Convert.ToString(e.resource)
                    + " Valore " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void buttonReadDigitalLevel_Click(object sender, EventArgs e)
        {
            try
            {
                FlagMethod = axPlexaNetKX1.ReadDigitalLevel(Convert.ToInt16(numericUpDownAddressDigitalLevel.Value), Convert.ToInt16(numericUpDownResourceDigitalLevel.Value));
            }
            catch (Exception)
            {
                LogString = " Selezionare INPUT "
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
            }
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " ReadDigitalLevel Method "
                    + "  : Flag " + Convert.ToString(FlagMethod)
                    + "\r\n"
                    + " Indirizzo " + Convert.ToString(numericUpDownAddressDigitalLevel.Value)
                    + " Risorsa " + Convert.ToString(numericUpDownResourceDigitalLevel.Value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnDigitalLevelRead(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnDigitalLevelReadEvent e)
        {
            pictureBoxOnDigitalLevel.Visible = true;
            timerOnAcknoledgeLed.Start();
            numericUpDownAddressDigitalLevel.Value = Convert.ToInt16(e.address);
            numericUpDownResourceDigitalLevel.Value = Convert.ToInt16(e.resource);
            textBoxValueDigitalLevel.Text = Convert.ToString(e.value);

            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnDigitalLevelRead Event"
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Risorsa " + Convert.ToString(e.resource)
                    + " Valore " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void textBoxVerbose_TextChanged(object sender, EventArgs e)
        {
            textBoxVerbose.Select(0, textBoxVerbose.Text.Length);
            textBoxVerbose.ScrollToCaret();
        }

        private void axPlexaNetKX1_OnError(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnErrorEvent e)
        {
            labelOnError.Enabled = true;
            textBoxErrorDesc.Text = e.errorDesc;
            timerOnAcknoledgeLed.Start();
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnError Event "
                    + " Codice Errore " + Convert.ToString(e.errorCode)
                    + " Descrizione Errore " + Convert.ToString(e.errorDesc)
                    + axPlexaNetKX1.Port
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void timerOnAcknoledgeLed_Tick(object sender, EventArgs e)
        {
            timerOnAcknoledgeLed.Stop();
            DisablePictureLedAck();
            textBoxErrorDesc.Text = "";
        }

        private void checkBoxVerbose_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxVerbose.Checked == true)
            {
                textBoxVerbose.Visible = true;
                this.Size = this.GetPreferredSize(this.Size);
                LogString = " Versione  Demo O C X :"
                    + Convert.ToString(myFI.FileVersion)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
            else
            {
                textBoxVerbose.Visible = false;
                this.Size = this.GetPreferredSize(this.Size);
            }
        }

        private void axPlexaNetKX1_OnDisplaySent(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnDisplaySentEvent e)
        {
            labelOnDisplaySent.Enabled = true;
            timerOnAcknoledgeLed.Start();
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnDisplaySent Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Riga " + Convert.ToString(e.resource)
                    + " Testo " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnLedsAndBuzzerSent(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnLedsAndBuzzerSentEvent e)
        {
            labelOnLedAndBuzzerSent.Enabled = true;
            timerOnAcknoledgeLed.Start();
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnLedsAndBuzzerSent Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Risorsa 1 "
                    + "\r\n"
                    + " Led RDY Value " + Convert.ToString(e.valueRdy)
                    + " Commutazioni " + Convert.ToString(e.countRdy)
                    + " Intervallo " + Convert.ToString(e.intervalRdy)
                    + " Led AUX Value " + Convert.ToString(e.valueAux)
                    + " Commutazioni " + Convert.ToString(e.countAux)
                    + " Intervallo " + Convert.ToString(e.intervalAux)
                    + " Led FBK Value " + Convert.ToString(e.valueFbk)
                    + " Commutazioni " + Convert.ToString(e.countFbk)
                    + " Intervallo " + Convert.ToString(e.intervalFbk)
                    + " Led OK Value " + Convert.ToString(e.valueOk)
                    + " Commutazioni " + Convert.ToString(e.countOk)
                    + " Intervallo " + Convert.ToString(e.intervalOk)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnDisplayError(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnDisplayErrorEvent e)
        {
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnDisplayError Event "
                    + " Codice Errore " + Convert.ToString(e.errorCode)
                    + " Descrizione Errore " + Convert.ToString(e.errorDesc)
                    + "\r\n"
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Riga " + Convert.ToString(e.resource)
                    + " Testo " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnLedsAndBuzzerError(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnLedsAndBuzzerErrorEvent e)
        {
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnLedsAndBuzzerError Event "
                    + " Codice Errore " + Convert.ToString(e.errorCode)
                    + " Descrizione Errore " + Convert.ToString(e.errorDesc)
                    + "\r\n"
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Risorsa 1 "
                    + "\r\n"
                    + " Led RDY Value " + Convert.ToString(e.valueRdy)
                    + " Commutazioni " + Convert.ToString(e.countRdy)
                    + " Intervallo " + Convert.ToString(e.intervalRdy)
                    + " Led AUX Value " + Convert.ToString(e.valueAux)
                    + " Commutazioni " + Convert.ToString(e.countAux)
                    + " Intervallo " + Convert.ToString(e.intervalAux)
                    + " Led FBK Value " + Convert.ToString(e.valueFbk)
                    + " Commutazioni " + Convert.ToString(e.countFbk)
                    + " Intervallo " + Convert.ToString(e.intervalFbk)
                    + " Led OK Value " + Convert.ToString(e.valueOk)
                    + " Commutazioni " + Convert.ToString(e.countOk)
                    + " Intervallo " + Convert.ToString(e.intervalOk)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnPulserError(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnPulserErrorEvent e)
        {
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnPulserError Event "
                    + " Codice Errore " + Convert.ToString(e.errorCode)
                    + " Descrizione Errore " + Convert.ToString(e.errorDesc)
                    + "\r\n"
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Rele' # " + Convert.ToString(e.resource)
                    + " Valore " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnDisplayRepeat(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnDisplayRepeatEvent e)
        {
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnDisplayRepeat Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Riga " + Convert.ToString(e.resource)
                    + " Testo " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnLedsAndBuzzerRepeat(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnLedsAndBuzzerRepeatEvent e)
        {
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnLedsAndBuzzerRepeat Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Risorsa 1 "
                    + "\r\n"
                    + " Led RDY Value " + Convert.ToString(e.valueRdy)
                    + " Commutazioni " + Convert.ToString(e.countRdy)
                    + " Intervallo " + Convert.ToString(e.intervalRdy)
                    + "\r\n"
                    + " Led AUX Value " + Convert.ToString(e.valueAux)
                    + " Commutazioni " + Convert.ToString(e.countAux)
                    + " Intervallo " + Convert.ToString(e.intervalAux)
                    + "\r\n"
                    + " Led FBK Value " + Convert.ToString(e.valueFbk)
                    + " Commutazioni " + Convert.ToString(e.countFbk)
                    + " Intervallo " + Convert.ToString(e.intervalFbk)
                    + "\r\n"
                    + " Led OK Value " + Convert.ToString(e.valueOk)
                    + " Commutazioni " + Convert.ToString(e.countOk)
                    + " Intervallo " + Convert.ToString(e.intervalOk)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnPulserRepeat(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnPulserRepeatEvent e)
        {
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnPulserRepeat Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Rele' # " + Convert.ToString(e.resource)
                    + " Valore " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnAddressOnLine(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnAddressOnLineEvent e)
        {
            DateTime OraCorrente = DateTime.Now;
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnAddressOnLine Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Ora " + OraCorrente.TimeOfDay
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnAddressOffLine(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnAddressOffLineEvent e)
        {
            DateTime OraCorrente = DateTime.Now;
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnAddressOffLine Event "
                          + " Indirizzo " + Convert.ToString(e.address)
                          + " Ora " + OraCorrente.TimeOfDay
                          + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnCompressedCodeEnter(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnCompressedCodeEnterEvent e)
        {
            pictureBoxOnCodeComp.Visible = true;
            timerOnAcknoledgeLed.Start();
            textBoxCompValue1.Text = e.value1;
            textBoxCompValue2.Text = e.value2;
            textBoxCompTecnology.Text = AuxFunction.IndiceTecnologia(e.technology);
            textBoxCompNid.Text = Convert.ToString(e.addressNid);
            textBoxCompSid.Text = Convert.ToString(e.addressSid);
            textBoxCompAddress.Text = Convert.ToString(e.address);
            textBoxCompResource.Text = AuxFunction.IndiceRisorsaComp(e.resource);

            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnCodeCompressedCodeEnter Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Risorsa " + AuxFunction.IndiceRisorsaComp(e.resource)
                    + " Tecnologia " + AuxFunction.IndiceTecnologia(e.technology)
                    + " Nid " + Convert.ToString(e.addressNid)
                    + " Sid " + Convert.ToString(e.addressSid)
                    + " Valore1: " + Convert.ToString(e.value1)
                    + " Valore2: " + Convert.ToString(e.value2)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void FormDemoPlexaNetK_Load(object sender, EventArgs e)
        {
            Text = "DemoPlexaNetK v. " + Convert.ToString(myFI.ProductVersion);
            checkBoxVerbose.Checked = true;
        }

        private void buttonUpdateCode_Click(object sender, EventArgs e)
        {
            bool FlagMethod;
            FlagMethod = axPlexaNetKX1.UpdateCode(Convert.ToInt16(numericUpDownAddressCode.Value), 1, 1, textBoxCodeValue.Text);
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " UpdateCode Method "
                    + "  : Flag " + Convert.ToString(FlagMethod)
                    + "\r\n"
                    + "Indirizzo " + Convert.ToString(numericUpDownAddressCode.Value) + " Risorsa 1 Tecnologia 1 "
                    + " Badge " + textBoxCodeValue.Text
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnCodeRepeat(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnCodeRepeatEvent e)
        {
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnCodeRepeat Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Risorsa " + Convert.ToString(e.resource)
                    + " Badge " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnCodeSent(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnCodeSentEvent e)
        {
            labelOnCodeSent.Enabled = true;
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnCodeSent Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Risorsa " + Convert.ToString(e.resource)
                    + " Badge " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnCodeError(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnCodeErrorEvent e)
        {
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnCodeError Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Risorsa " + Convert.ToString(e.resource)
                    + " Badge " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnCodeUpdate(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnCodeUpdateEvent e)
        {
            pictureBoxOnCodeUpdate.Visible = true;
            timerOnAcknoledgeLed.Start();
            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnCodeUpdate Event "
                    + " Indirizzo " + Convert.ToString(e.address)
                    + " Riga " + Convert.ToString(e.resource)
                    + " Testo " + Convert.ToString(e.value)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void axPlexaNetKX1_OnNewNodeParameters(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnNewNodeParametersEvent e)
        {
            pictureBoxOnParameters.Visible = true;
            timerOnAcknoledgeLed.Start();

            if (e.mode == 1)
            {
                radioButtonDSWRemote.Checked = true;
                radioButtonDSWLocal.Checked = false;
            }
            else
            {
                radioButtonDSWRemote.Checked = false;
                radioButtonDSWLocal.Checked = true;
            }
            bool Par1 = (((byte)e.parameters[0] & 0x01) != 0) ? true : false;
            bool Par2 = (((byte)e.parameters[0] & 0x02) != 0) ? true : false;
            bool Par3 = (((byte)e.parameters[0] & 0x04) != 0) ? true : false;
            bool Par4 = (((byte)e.parameters[0] & 0x08) != 0) ? true : false;

            if (Par1)
            {
                radioButtonPar1ON.Checked = true;
            }
            else if (!Par1)
            {
                radioButtonPar1OFF.Checked = true;
            }

            if (Par2)
            {
                radioButtonPar2ON.Checked = true;
            }
            else if (!Par2)
            {
                radioButtonPar2OFF.Checked = true;
            }

            if (Par3)
            {
                radioButtonPar3ON.Checked = true;
            }
            else if (!Par3)
            {
                radioButtonPar3OFF.Checked = true;
            }

            if (Par4)
            {
                radioButtonPar4ON.Checked = true;
            }
            else if (!Par4)
            {
                radioButtonPar4OFF.Checked = true;
            }
        }

        private void buttonGetParameters_Click(object sender, EventArgs e)
        {
            foreach (RadioButton RB in groupBoxLOCREM.Controls)
                RB.Checked = false;
            foreach (RadioButton RB in groupBoxPar1.Controls)
                RB.Checked = false;
            foreach (RadioButton RB in groupBoxPar2.Controls)
                RB.Checked = false;
            foreach (RadioButton RB in groupBoxPar3.Controls)
                RB.Checked = false;
            foreach (RadioButton RB in groupBoxPar4.Controls)
                RB.Checked = false;
            axPlexaNetKX1.RequestNodeParameters(Convert.ToInt16(numericUpDownParameters.Value));
        }

        private void axPlexaNetKX1_OnNodeInfo(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnNodeInfoEvent e)
        {
            byte LsbVer1 = (byte)(e.mainVersion & 0x0F);
            byte MsbVer1 = (byte)((e.mainVersion & 0xF0) >> 4);
            byte LsbVer2 = (byte)(e.subVersion & 0x0F);
            byte MsbVer2 = (byte)((e.subVersion & 0xF0) >> 4);
            String StatusString;
            switch (e.status)
            {
                case 0x30:
                    StatusString = "Reset";
                    break;
                case 0x31:
                    StatusString = "Risposta";
                    break;
                case 0x32:
                    StatusString = "Serv.Pin";
                    break;
                default:
                    StatusString = "Sconosciuto";
                    break;
            }

            if (checkBoxVerbose.Checked == true)
            {
                LogString = " OnNodeInfo Event "
                    + "Status:" + StatusString
                    + " NID=" + Convert.ToString(e.address)
                    + " SID=" + Convert.ToString(e.subAddress)
                    + " KID=" + Convert.ToString(e.kid)
                    + " Main Vers. " + Convert.ToString(MsbVer1) + "." + Convert.ToString(LsbVer1)
                    + " Sec Vers. " + Convert.ToString(MsbVer2) + "." + Convert.ToString(LsbVer2)
                    + "\r\n";
                textBoxVerbose.AppendText(LogString);
                AuxFunction.Log(LogString);
            }
        }

        private void checkBoxSingleNode_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxSingleNode.Checked)
            {
                numericUpDownSingleNode.Visible = true;
                axPlexaNetKX1.SingleDeviceToConnect =
                  (int)numericUpDownSingleNode.Value;
            }
            else
            {
                numericUpDownSingleNode.Visible = false;
                axPlexaNetKX1.SingleDeviceToConnect = 255;
            }
        }

        private void numericUpDownSingleNode_ValueChanged(object sender, EventArgs e)
        {
            if (checkBoxSingleNode.Checked)
            {
                axPlexaNetKX1.SingleDeviceToConnect =
                 (int)numericUpDownSingleNode.Value;
            }
        }

        private void textBoxIP_TextChanged(object sender, EventArgs e)
        {
            radioButtonServer.Checked = true;
            radioButtonPort.Checked = false;
        }

        private void comboBoxCOM_TextChanged(object sender, EventArgs e)
        {
            radioButtonServer.Checked = false;
            radioButtonPort.Checked = true;
        }
    }
}

