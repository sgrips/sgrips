using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;


namespace DemoPlexaNetK
{
    public class FunctionDemoPlexaNetK
    {
        private const string DIRECTORY_LOG = "\\Plexa\\DemoPlexaNetK\\Log\\";
        private const string DIRECTORY_PLEXA = "\\Plexa\\";
        private const string DIRECTORY_APPL = "\\Plexa\\DemoPlexaNetK";
        static string PublicDataDir =
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
        static string LogDir = PublicDataDir + DIRECTORY_LOG;
        public static string PlexaDir = PublicDataDir + DIRECTORY_PLEXA;
        public static string ApplDataDir = PublicDataDir + DIRECTORY_APPL;
        static string NomeFileLog = LogDir + "LOGDemoPlexaNetK_"
                                    + DateTime.Now.ToShortDateString().Replace(" ", "").Replace("/", "-")
                                    + "_" + DateTime.Now.ToShortTimeString().Replace(" ", "").Replace("/", "-") + ".txt";

        public StreamWriter w1;

        public void Log(String logMessage)
        {
            try
            {
                if (!Directory.Exists(LogDir))
                {
                    Directory.CreateDirectory(LogDir);
                }
                w1 = File.AppendText(NomeFileLog);
                w1.Write("\r\nLog Entry : ");
                w1.WriteLine("{0} {1}", DateTime.Now.ToLongTimeString(),
                    DateTime.Now.ToLongDateString());
                w1.WriteLine("  :");
                w1.WriteLine("  :{0}", logMessage);
                w1.WriteLine("-------------------------------");
                // Update the underlying file.
                w1.Flush();
                w1.Close();
            }
            catch
            {
                MessageBox.Show(" Error Access Log File ");
            }
        }
        public string IndiceRisorsa(int Risorsa)
        {
            switch (Risorsa)
            {
                case 1:
                    return "Tastiera o Impronta";
                case 2:
                    return "Badge Sx->>Dx o Tag PE";
                case 3:
                    return "Badge Sx<<-Dx";
                case 4:
                    return "Transp. Passivo";
                case 5:
                    return "Badge Aux Sx->>Dx";
                case 6:
                    return "Badge Aux Sx<<-Dx";
                case 7:
                    return "Transp. Pass. Aux";
                case 8:
                    return "Non Usato 8";
                default:
                    return "Indice Risorsa Errato";
            }
        }

        public string IndiceRisorsaComp(int Risorsa)
        {
            switch (Risorsa)
            {
                case 1:
                    return "Tag PE1 o Conv. da PLW";
                case 2:
                    return "Tag PE2";
                case 3:
                    return "Tag PE3";
                case 4:
                    return "Tag PE4";
                case 5:
                    return "Non Usato 5";
                case 6:
                    return "Non Usato 6";
                case 7:
                    return "Non Usato 7";
                case 8:
                    return "Non Usato 8";
                default:
                    return "Indice Risorsa Errato";
            }
        }

        public string IndiceTecnologia(int Tecnologia)
        {
            switch (Tecnologia)
            {
                case 0:
                    return "Badge Magnetico";
                case 1:
                    return "Transp. Prox Q5";
                case 2:
                    return "Tastiera";
                case 3:
                    return "Non Usato";
                case 4:
                    return "Transp. Passive Entry";
                case 5:
                    return "Transp. Prox Mifare";
                case 6:
                    return "Traspo. Prox I-Code";
                case 7:
                    return "Convers. da rete PLW";
                case 8:
                    return "Impronta Biometrico";
                case 9:
                    return "Contatore PEntry";
                case 10:
                    return "Codice wiegand";
                default:
                    return "Indice Tecnologia Errato";
            }
        }

       
    }
}
