namespace DemoPlexaNetK
{
    partial class FormDemoPlexaNetK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDemoPlexaNetK));
            this.groupBoxKEInterface = new System.Windows.Forms.GroupBox();
            this.checkBoxSingleNode = new System.Windows.Forms.CheckBox();
            this.numericUpDownSingleNode = new System.Windows.Forms.NumericUpDown();
            this.checkBoxAcknowledge = new System.Windows.Forms.CheckBox();
            this.comboBoxCOM = new System.Windows.Forms.ComboBox();
            this.textBoxIP = new System.Windows.Forms.TextBox();
            this.radioButtonServer = new System.Windows.Forms.RadioButton();
            this.radioButtonPort = new System.Windows.Forms.RadioButton();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.buttonDisconnect = new System.Windows.Forms.Button();
            this.groupBoxDisplay = new System.Windows.Forms.GroupBox();
            this.checkBoxRow2 = new System.Windows.Forms.CheckBox();
            this.checkBoxRow1 = new System.Windows.Forms.CheckBox();
            this.labelOnDisplaySent = new System.Windows.Forms.Label();
            this.labelAddressDisplay = new System.Windows.Forms.Label();
            this.pictureBoxOnDisplayUpdate = new System.Windows.Forms.PictureBox();
            this.numericUpDownAddressDisplay = new System.Windows.Forms.NumericUpDown();
            this.pictureBoxOnDisplayRead = new System.Windows.Forms.PictureBox();
            this.buttonUpdateDisplay = new System.Windows.Forms.Button();
            this.buttonReadDisplay = new System.Windows.Forms.Button();
            this.labelRiga2 = new System.Windows.Forms.Label();
            this.labelRiga1 = new System.Windows.Forms.Label();
            this.textBoxRow2 = new System.Windows.Forms.TextBox();
            this.textBoxRow1 = new System.Windows.Forms.TextBox();
            this.groupBoxInfoK = new System.Windows.Forms.GroupBox();
            this.pictureBoxOnCodeEnter = new System.Windows.Forms.PictureBox();
            this.labelTecnologyK = new System.Windows.Forms.Label();
            this.labelResourceK = new System.Windows.Forms.Label();
            this.labelValueK = new System.Windows.Forms.Label();
            this.labelAddressK = new System.Windows.Forms.Label();
            this.textBoxTecnologyK = new System.Windows.Forms.TextBox();
            this.textBoxResourceK = new System.Windows.Forms.TextBox();
            this.textBoxValueK = new System.Windows.Forms.TextBox();
            this.textBoxAddressK = new System.Windows.Forms.TextBox();
            this.groupBoxLed_Buzzer = new System.Windows.Forms.GroupBox();
            this.labelOnLedAndBuzzerSent = new System.Windows.Forms.Label();
            this.pictureBoxOnUpdateLed_Buzzer = new System.Windows.Forms.PictureBox();
            this.labelAddressLed_Buzzer = new System.Windows.Forms.Label();
            this.groupBoxAdvancedLed = new System.Windows.Forms.GroupBox();
            this.checkBoxOk = new System.Windows.Forms.CheckBox();
            this.labelOk = new System.Windows.Forms.Label();
            this.checkBoxFbk = new System.Windows.Forms.CheckBox();
            this.labelFbk = new System.Windows.Forms.Label();
            this.checkBoxAux = new System.Windows.Forms.CheckBox();
            this.labelAux = new System.Windows.Forms.Label();
            this.checkBoxRdy = new System.Windows.Forms.CheckBox();
            this.pictureBoxLedOk = new System.Windows.Forms.PictureBox();
            this.pictureBoxLedFbk = new System.Windows.Forms.PictureBox();
            this.pictureBoxLedAux = new System.Windows.Forms.PictureBox();
            this.labelRdy = new System.Windows.Forms.Label();
            this.numericUpDownCountLedOk = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownIntervalLedOk = new System.Windows.Forms.NumericUpDown();
            this.pictureBoxLedRdy = new System.Windows.Forms.PictureBox();
            this.numericUpDownCountLedFbk = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownIntervalLedFbk = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownCountLedAux = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownIntervalLedAux = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownValueBuzzer = new System.Windows.Forms.NumericUpDown();
            this.labelValueBuz = new System.Windows.Forms.Label();
            this.numericUpDownIntervalBuzzer = new System.Windows.Forms.NumericUpDown();
            this.labelCountLed = new System.Windows.Forms.Label();
            this.labelIntervalLed = new System.Windows.Forms.Label();
            this.numericUpDownCountLedRdy = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownIntervalLedRdy = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownAddressLed_Buzzer = new System.Windows.Forms.NumericUpDown();
            this.buttonUpdate_Buzzer = new System.Windows.Forms.Button();
            this.buttonUpdateLed = new System.Windows.Forms.Button();
            this.groupBoxPulser = new System.Windows.Forms.GroupBox();
            this.labelOnPulserSent = new System.Windows.Forms.Label();
            this.numericUpDownResourcePulser = new System.Windows.Forms.NumericUpDown();
            this.labelResourcePulser = new System.Windows.Forms.Label();
            this.numericUpDownValuePulser = new System.Windows.Forms.NumericUpDown();
            this.labelValuePulser = new System.Windows.Forms.Label();
            this.buttonUpdatePulser = new System.Windows.Forms.Button();
            this.pictureBoxOnPulserUpdate = new System.Windows.Forms.PictureBox();
            this.labelAddressPulser = new System.Windows.Forms.Label();
            this.groupBoxAdvancedPulser = new System.Windows.Forms.GroupBox();
            this.labelCountPulser = new System.Windows.Forms.Label();
            this.labelIntervalPulser = new System.Windows.Forms.Label();
            this.numericUpDownCountPulser = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownIntervalPulser = new System.Windows.Forms.NumericUpDown();
            this.pictureBoxOnPulserRead = new System.Windows.Forms.PictureBox();
            this.numericUpDownAddressPulser = new System.Windows.Forms.NumericUpDown();
            this.buttonPulserRead = new System.Windows.Forms.Button();
            this.buttonReadDigitalLevel = new System.Windows.Forms.Button();
            this.textBoxVerbose = new System.Windows.Forms.TextBox();
            this.groupBoxTamper = new System.Windows.Forms.GroupBox();
            this.labelValueTamper = new System.Windows.Forms.Label();
            this.textBoxValueTamper = new System.Windows.Forms.TextBox();
            this.labelAddressTamper = new System.Windows.Forms.Label();
            this.textBoxAddressTamper = new System.Windows.Forms.TextBox();
            this.labelOnError = new System.Windows.Forms.Label();
            this.groupBoxDigitalLevel = new System.Windows.Forms.GroupBox();
            this.numericUpDownResourceDigitalLevel = new System.Windows.Forms.NumericUpDown();
            this.labelResourceReadDigitalLevel = new System.Windows.Forms.Label();
            this.labelValueDigitalLevel = new System.Windows.Forms.Label();
            this.textBoxValueDigitalLevel = new System.Windows.Forms.TextBox();
            this.labelAddressDigitalLevel = new System.Windows.Forms.Label();
            this.numericUpDownAddressDigitalLevel = new System.Windows.Forms.NumericUpDown();
            this.pictureBoxOnDigitalLevel = new System.Windows.Forms.PictureBox();
            this.groupBoxKeyEnter = new System.Windows.Forms.GroupBox();
            this.labelKeyEnterValue = new System.Windows.Forms.Label();
            this.textBoxValueKey = new System.Windows.Forms.TextBox();
            this.labelAddressKey = new System.Windows.Forms.Label();
            this.textBoxAddressKey = new System.Windows.Forms.TextBox();
            this.labelInput = new System.Windows.Forms.Label();
            this.labelOutput = new System.Windows.Forms.Label();
            this.checkBoxVerbose = new System.Windows.Forms.CheckBox();
            this.timerOnAcknoledgeLed = new System.Windows.Forms.Timer(this.components);
            this.textBoxErrorDesc = new System.Windows.Forms.TextBox();
            this.groupBoxCodeComp = new System.Windows.Forms.GroupBox();
            this.labelCompResourceK = new System.Windows.Forms.Label();
            this.textBoxCompResource = new System.Windows.Forms.TextBox();
            this.labelCompTeck = new System.Windows.Forms.Label();
            this.pictureBoxOnCodeComp = new System.Windows.Forms.PictureBox();
            this.labelCompSid = new System.Windows.Forms.Label();
            this.textBoxCompTecnology = new System.Windows.Forms.TextBox();
            this.labelValue2K = new System.Windows.Forms.Label();
            this.textBoxCompSid = new System.Windows.Forms.TextBox();
            this.labelValue1K = new System.Windows.Forms.Label();
            this.textBoxCompNid = new System.Windows.Forms.TextBox();
            this.labelCompNid = new System.Windows.Forms.Label();
            this.textBoxCompValue2 = new System.Windows.Forms.TextBox();
            this.textBoxCompValue1 = new System.Windows.Forms.TextBox();
            this.textBoxCompAddress = new System.Windows.Forms.TextBox();
            this.labelCompAddress = new System.Windows.Forms.Label();
            this.groupBoxCode = new System.Windows.Forms.GroupBox();
            this.labelOnCodeSent = new System.Windows.Forms.Label();
            this.labelAddressCode = new System.Windows.Forms.Label();
            this.pictureBoxOnCodeUpdate = new System.Windows.Forms.PictureBox();
            this.numericUpDownAddressCode = new System.Windows.Forms.NumericUpDown();
            this.buttonUpdateCode = new System.Windows.Forms.Button();
            this.textBoxCodeValue = new System.Windows.Forms.TextBox();
            this.groupBoxParameters = new System.Windows.Forms.GroupBox();
            this.pictureBoxOnParameters = new System.Windows.Forms.PictureBox();
            this.groupBoxPar4 = new System.Windows.Forms.GroupBox();
            this.radioButtonPar4OFF = new System.Windows.Forms.RadioButton();
            this.radioButtonPar4ON = new System.Windows.Forms.RadioButton();
            this.labelAddressParameters = new System.Windows.Forms.Label();
            this.groupBoxLOCREM = new System.Windows.Forms.GroupBox();
            this.radioButtonDSWLocal = new System.Windows.Forms.RadioButton();
            this.radioButtonDSWRemote = new System.Windows.Forms.RadioButton();
            this.groupBoxPar3 = new System.Windows.Forms.GroupBox();
            this.radioButtonPar3ON = new System.Windows.Forms.RadioButton();
            this.radioButtonPar3OFF = new System.Windows.Forms.RadioButton();
            this.groupBoxPar1 = new System.Windows.Forms.GroupBox();
            this.radioButtonPar1ON = new System.Windows.Forms.RadioButton();
            this.radioButtonPar1OFF = new System.Windows.Forms.RadioButton();
            this.groupBoxPar2 = new System.Windows.Forms.GroupBox();
            this.radioButtonPar2ON = new System.Windows.Forms.RadioButton();
            this.radioButtonPar2OFF = new System.Windows.Forms.RadioButton();
            this.buttonGetParameters = new System.Windows.Forms.Button();
            this.numericUpDownParameters = new System.Windows.Forms.NumericUpDown();
            this.pictureBoxPlexa = new System.Windows.Forms.PictureBox();
            this.pictureBoxDisconnect = new System.Windows.Forms.PictureBox();
            this.pictureBoxConnect = new System.Windows.Forms.PictureBox();
            this.axPlexaNetKX1 = new AxPlexaNetKProj1.AxPlexaNetKX();
            this.pictureBoxOnKeyEnter = new System.Windows.Forms.PictureBox();
            this.pictureBoxOnTamperChange = new System.Windows.Forms.PictureBox();
            this.groupBoxKEInterface.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSingleNode)).BeginInit();
            this.groupBoxDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnDisplayUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAddressDisplay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnDisplayRead)).BeginInit();
            this.groupBoxInfoK.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnCodeEnter)).BeginInit();
            this.groupBoxLed_Buzzer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnUpdateLed_Buzzer)).BeginInit();
            this.groupBoxAdvancedLed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLedOk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLedFbk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLedAux)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCountLedOk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntervalLedOk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLedRdy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCountLedFbk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntervalLedFbk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCountLedAux)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntervalLedAux)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownValueBuzzer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntervalBuzzer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCountLedRdy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntervalLedRdy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAddressLed_Buzzer)).BeginInit();
            this.groupBoxPulser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownResourcePulser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownValuePulser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnPulserUpdate)).BeginInit();
            this.groupBoxAdvancedPulser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCountPulser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntervalPulser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnPulserRead)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAddressPulser)).BeginInit();
            this.groupBoxTamper.SuspendLayout();
            this.groupBoxDigitalLevel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownResourceDigitalLevel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAddressDigitalLevel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnDigitalLevel)).BeginInit();
            this.groupBoxKeyEnter.SuspendLayout();
            this.groupBoxCodeComp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnCodeComp)).BeginInit();
            this.groupBoxCode.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnCodeUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAddressCode)).BeginInit();
            this.groupBoxParameters.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnParameters)).BeginInit();
            this.groupBoxPar4.SuspendLayout();
            this.groupBoxLOCREM.SuspendLayout();
            this.groupBoxPar3.SuspendLayout();
            this.groupBoxPar1.SuspendLayout();
            this.groupBoxPar2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownParameters)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlexa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDisconnect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxConnect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axPlexaNetKX1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnKeyEnter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnTamperChange)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxKEInterface
            // 
            this.groupBoxKEInterface.Controls.Add(this.checkBoxSingleNode);
            this.groupBoxKEInterface.Controls.Add(this.numericUpDownSingleNode);
            this.groupBoxKEInterface.Controls.Add(this.checkBoxAcknowledge);
            this.groupBoxKEInterface.Controls.Add(this.comboBoxCOM);
            this.groupBoxKEInterface.Controls.Add(this.textBoxIP);
            this.groupBoxKEInterface.Controls.Add(this.radioButtonServer);
            this.groupBoxKEInterface.Controls.Add(this.radioButtonPort);
            this.groupBoxKEInterface.Location = new System.Drawing.Point(15, 6);
            this.groupBoxKEInterface.Name = "groupBoxKEInterface";
            this.groupBoxKEInterface.Size = new System.Drawing.Size(314, 65);
            this.groupBoxKEInterface.TabIndex = 1;
            this.groupBoxKEInterface.TabStop = false;
            this.groupBoxKEInterface.Text = "Connessione KE";
            // 
            // checkBoxSingleNode
            // 
            this.checkBoxSingleNode.AutoSize = true;
            this.checkBoxSingleNode.Location = new System.Drawing.Point(173, 17);
            this.checkBoxSingleNode.Name = "checkBoxSingleNode";
            this.checkBoxSingleNode.Size = new System.Drawing.Size(82, 17);
            this.checkBoxSingleNode.TabIndex = 7;
            this.checkBoxSingleNode.Text = "Singlo nodo";
            this.checkBoxSingleNode.UseVisualStyleBackColor = true;
            this.checkBoxSingleNode.CheckedChanged += new System.EventHandler(this.checkBoxSingleNode_CheckedChanged);
            // 
            // numericUpDownSingleNode
            // 
            this.numericUpDownSingleNode.Location = new System.Drawing.Point(261, 14);
            this.numericUpDownSingleNode.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownSingleNode.Name = "numericUpDownSingleNode";
            this.numericUpDownSingleNode.Size = new System.Drawing.Size(43, 20);
            this.numericUpDownSingleNode.TabIndex = 5;
            this.numericUpDownSingleNode.Visible = false;
            this.numericUpDownSingleNode.ValueChanged += new System.EventHandler(this.numericUpDownSingleNode_ValueChanged);
            // 
            // checkBoxAcknowledge
            // 
            this.checkBoxAcknowledge.AutoSize = true;
            this.checkBoxAcknowledge.Checked = true;
            this.checkBoxAcknowledge.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAcknowledge.Location = new System.Drawing.Point(172, 42);
            this.checkBoxAcknowledge.Name = "checkBoxAcknowledge";
            this.checkBoxAcknowledge.Size = new System.Drawing.Size(136, 17);
            this.checkBoxAcknowledge.TabIndex = 4;
            this.checkBoxAcknowledge.Text = "Modalita\' Acknowledge";
            this.checkBoxAcknowledge.UseVisualStyleBackColor = true;
            // 
            // comboBoxCOM
            // 
            this.comboBoxCOM.FormattingEnabled = true;
            this.comboBoxCOM.Items.AddRange(new object[] {
            "COM1:",
            "COM2:",
            "COM3:",
            "COM4:",
            "COM5:",
            "COM6:",
            "COM7:",
            "COM8:"});
            this.comboBoxCOM.Location = new System.Drawing.Point(68, 15);
            this.comboBoxCOM.Name = "comboBoxCOM";
            this.comboBoxCOM.Size = new System.Drawing.Size(94, 21);
            this.comboBoxCOM.TabIndex = 3;
            this.comboBoxCOM.Text = "COM1:";
            this.comboBoxCOM.TextChanged += new System.EventHandler(this.comboBoxCOM_TextChanged);
            // 
            // textBoxIP
            // 
            this.textBoxIP.Location = new System.Drawing.Point(68, 40);
            this.textBoxIP.Name = "textBoxIP";
            this.textBoxIP.Size = new System.Drawing.Size(93, 20);
            this.textBoxIP.TabIndex = 2;
            this.textBoxIP.Text = "10.0.0.208";
            this.textBoxIP.TextChanged += new System.EventHandler(this.textBoxIP_TextChanged);
            // 
            // radioButtonServer
            // 
            this.radioButtonServer.AutoSize = true;
            this.radioButtonServer.Location = new System.Drawing.Point(12, 41);
            this.radioButtonServer.Name = "radioButtonServer";
            this.radioButtonServer.Size = new System.Drawing.Size(56, 17);
            this.radioButtonServer.TabIndex = 1;
            this.radioButtonServer.TabStop = true;
            this.radioButtonServer.Text = "Server";
            this.radioButtonServer.UseVisualStyleBackColor = true;
            this.radioButtonServer.CheckedChanged += new System.EventHandler(this.radioButtonServer_CheckedChanged);
            // 
            // radioButtonPort
            // 
            this.radioButtonPort.AutoSize = true;
            this.radioButtonPort.Location = new System.Drawing.Point(12, 19);
            this.radioButtonPort.Name = "radioButtonPort";
            this.radioButtonPort.Size = new System.Drawing.Size(50, 17);
            this.radioButtonPort.TabIndex = 0;
            this.radioButtonPort.TabStop = true;
            this.radioButtonPort.Text = "Porta";
            this.radioButtonPort.UseVisualStyleBackColor = true;
            this.radioButtonPort.CheckedChanged += new System.EventHandler(this.radioButtonPort_CheckedChanged);
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(335, 11);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(73, 26);
            this.buttonConnect.TabIndex = 2;
            this.buttonConnect.Text = "Connetti";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // buttonDisconnect
            // 
            this.buttonDisconnect.Location = new System.Drawing.Point(335, 44);
            this.buttonDisconnect.Name = "buttonDisconnect";
            this.buttonDisconnect.Size = new System.Drawing.Size(73, 26);
            this.buttonDisconnect.TabIndex = 3;
            this.buttonDisconnect.Text = "Disconnetti";
            this.buttonDisconnect.UseVisualStyleBackColor = true;
            this.buttonDisconnect.Click += new System.EventHandler(this.buttonDisconnect_Click);
            // 
            // groupBoxDisplay
            // 
            this.groupBoxDisplay.Controls.Add(this.checkBoxRow2);
            this.groupBoxDisplay.Controls.Add(this.checkBoxRow1);
            this.groupBoxDisplay.Controls.Add(this.labelOnDisplaySent);
            this.groupBoxDisplay.Controls.Add(this.labelAddressDisplay);
            this.groupBoxDisplay.Controls.Add(this.pictureBoxOnDisplayUpdate);
            this.groupBoxDisplay.Controls.Add(this.numericUpDownAddressDisplay);
            this.groupBoxDisplay.Controls.Add(this.pictureBoxOnDisplayRead);
            this.groupBoxDisplay.Controls.Add(this.buttonUpdateDisplay);
            this.groupBoxDisplay.Controls.Add(this.buttonReadDisplay);
            this.groupBoxDisplay.Controls.Add(this.labelRiga2);
            this.groupBoxDisplay.Controls.Add(this.labelRiga1);
            this.groupBoxDisplay.Controls.Add(this.textBoxRow2);
            this.groupBoxDisplay.Controls.Add(this.textBoxRow1);
            this.groupBoxDisplay.Enabled = false;
            this.groupBoxDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxDisplay.Location = new System.Drawing.Point(367, 157);
            this.groupBoxDisplay.Name = "groupBoxDisplay";
            this.groupBoxDisplay.Size = new System.Drawing.Size(360, 96);
            this.groupBoxDisplay.TabIndex = 4;
            this.groupBoxDisplay.TabStop = false;
            this.groupBoxDisplay.Text = "Display";
            // 
            // checkBoxRow2
            // 
            this.checkBoxRow2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxRow2.AutoSize = true;
            this.checkBoxRow2.Checked = true;
            this.checkBoxRow2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxRow2.Location = new System.Drawing.Point(101, 61);
            this.checkBoxRow2.Margin = new System.Windows.Forms.Padding(1);
            this.checkBoxRow2.Name = "checkBoxRow2";
            this.checkBoxRow2.Padding = new System.Windows.Forms.Padding(1);
            this.checkBoxRow2.Size = new System.Drawing.Size(17, 16);
            this.checkBoxRow2.TabIndex = 33;
            this.checkBoxRow2.UseVisualStyleBackColor = true;
            // 
            // checkBoxRow1
            // 
            this.checkBoxRow1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxRow1.AutoSize = true;
            this.checkBoxRow1.Checked = true;
            this.checkBoxRow1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxRow1.Location = new System.Drawing.Point(101, 30);
            this.checkBoxRow1.Margin = new System.Windows.Forms.Padding(1);
            this.checkBoxRow1.Name = "checkBoxRow1";
            this.checkBoxRow1.Padding = new System.Windows.Forms.Padding(1);
            this.checkBoxRow1.Size = new System.Drawing.Size(17, 16);
            this.checkBoxRow1.TabIndex = 32;
            this.checkBoxRow1.UseVisualStyleBackColor = true;
            // 
            // labelOnDisplaySent
            // 
            this.labelOnDisplaySent.AutoSize = true;
            this.labelOnDisplaySent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOnDisplaySent.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelOnDisplaySent.Location = new System.Drawing.Point(305, 78);
            this.labelOnDisplaySent.Margin = new System.Windows.Forms.Padding(0);
            this.labelOnDisplaySent.Name = "labelOnDisplaySent";
            this.labelOnDisplaySent.Size = new System.Drawing.Size(47, 16);
            this.labelOnDisplaySent.TabIndex = 29;
            this.labelOnDisplaySent.Text = "Inviato";
            // 
            // labelAddressDisplay
            // 
            this.labelAddressDisplay.AutoSize = true;
            this.labelAddressDisplay.Location = new System.Drawing.Point(14, 17);
            this.labelAddressDisplay.Name = "labelAddressDisplay";
            this.labelAddressDisplay.Size = new System.Drawing.Size(45, 13);
            this.labelAddressDisplay.TabIndex = 14;
            this.labelAddressDisplay.Text = "Indirizzo";
            // 
            // pictureBoxOnDisplayUpdate
            // 
            this.pictureBoxOnDisplayUpdate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxOnDisplayUpdate.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxOnDisplayUpdate.Location = new System.Drawing.Point(326, 59);
            this.pictureBoxOnDisplayUpdate.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBoxOnDisplayUpdate.Name = "pictureBoxOnDisplayUpdate";
            this.pictureBoxOnDisplayUpdate.Size = new System.Drawing.Size(26, 18);
            this.pictureBoxOnDisplayUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxOnDisplayUpdate.TabIndex = 8;
            this.pictureBoxOnDisplayUpdate.TabStop = false;
            // 
            // numericUpDownAddressDisplay
            // 
            this.numericUpDownAddressDisplay.Location = new System.Drawing.Point(17, 33);
            this.numericUpDownAddressDisplay.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.numericUpDownAddressDisplay.Name = "numericUpDownAddressDisplay";
            this.numericUpDownAddressDisplay.Size = new System.Drawing.Size(42, 20);
            this.numericUpDownAddressDisplay.TabIndex = 13;
            this.numericUpDownAddressDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownAddressDisplay.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pictureBoxOnDisplayRead
            // 
            this.pictureBoxOnDisplayRead.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxOnDisplayRead.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxOnDisplayRead.Location = new System.Drawing.Point(326, 33);
            this.pictureBoxOnDisplayRead.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBoxOnDisplayRead.Name = "pictureBoxOnDisplayRead";
            this.pictureBoxOnDisplayRead.Size = new System.Drawing.Size(26, 18);
            this.pictureBoxOnDisplayRead.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxOnDisplayRead.TabIndex = 7;
            this.pictureBoxOnDisplayRead.TabStop = false;
            // 
            // buttonUpdateDisplay
            // 
            this.buttonUpdateDisplay.Location = new System.Drawing.Point(253, 55);
            this.buttonUpdateDisplay.Margin = new System.Windows.Forms.Padding(1);
            this.buttonUpdateDisplay.Name = "buttonUpdateDisplay";
            this.buttonUpdateDisplay.Size = new System.Drawing.Size(62, 22);
            this.buttonUpdateDisplay.TabIndex = 5;
            this.buttonUpdateDisplay.Text = " Scrivi";
            this.buttonUpdateDisplay.UseVisualStyleBackColor = true;
            this.buttonUpdateDisplay.Click += new System.EventHandler(this.buttonUpdateDisplay_Click);
            // 
            // buttonReadDisplay
            // 
            this.buttonReadDisplay.Location = new System.Drawing.Point(253, 26);
            this.buttonReadDisplay.Margin = new System.Windows.Forms.Padding(1);
            this.buttonReadDisplay.Name = "buttonReadDisplay";
            this.buttonReadDisplay.Size = new System.Drawing.Size(62, 22);
            this.buttonReadDisplay.TabIndex = 4;
            this.buttonReadDisplay.Text = "Leggi";
            this.buttonReadDisplay.UseVisualStyleBackColor = true;
            this.buttonReadDisplay.Click += new System.EventHandler(this.buttonReadDisplay_Click);
            // 
            // labelRiga2
            // 
            this.labelRiga2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelRiga2.AutoSize = true;
            this.labelRiga2.Location = new System.Drawing.Point(62, 61);
            this.labelRiga2.Margin = new System.Windows.Forms.Padding(3);
            this.labelRiga2.Name = "labelRiga2";
            this.labelRiga2.Size = new System.Drawing.Size(35, 13);
            this.labelRiga2.TabIndex = 3;
            this.labelRiga2.Text = "Riga2";
            // 
            // labelRiga1
            // 
            this.labelRiga1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelRiga1.AutoSize = true;
            this.labelRiga1.Location = new System.Drawing.Point(62, 32);
            this.labelRiga1.Margin = new System.Windows.Forms.Padding(3);
            this.labelRiga1.Name = "labelRiga1";
            this.labelRiga1.Size = new System.Drawing.Size(35, 13);
            this.labelRiga1.TabIndex = 2;
            this.labelRiga1.Text = "Riga1";
            // 
            // textBoxRow2
            // 
            this.textBoxRow2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxRow2.Location = new System.Drawing.Point(126, 55);
            this.textBoxRow2.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxRow2.MaxLength = 28;
            this.textBoxRow2.Name = "textBoxRow2";
            this.textBoxRow2.Size = new System.Drawing.Size(120, 26);
            this.textBoxRow2.TabIndex = 1;
            this.textBoxRow2.Text = "Welcome";
            // 
            // textBoxRow1
            // 
            this.textBoxRow1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxRow1.Location = new System.Drawing.Point(126, 27);
            this.textBoxRow1.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxRow1.MaxLength = 28;
            this.textBoxRow1.Name = "textBoxRow1";
            this.textBoxRow1.Size = new System.Drawing.Size(120, 26);
            this.textBoxRow1.TabIndex = 0;
            this.textBoxRow1.Text = "Benvenuti";
            // 
            // groupBoxInfoK
            // 
            this.groupBoxInfoK.Controls.Add(this.pictureBoxOnCodeEnter);
            this.groupBoxInfoK.Controls.Add(this.labelTecnologyK);
            this.groupBoxInfoK.Controls.Add(this.labelResourceK);
            this.groupBoxInfoK.Controls.Add(this.labelValueK);
            this.groupBoxInfoK.Controls.Add(this.labelAddressK);
            this.groupBoxInfoK.Controls.Add(this.textBoxTecnologyK);
            this.groupBoxInfoK.Controls.Add(this.textBoxResourceK);
            this.groupBoxInfoK.Controls.Add(this.textBoxValueK);
            this.groupBoxInfoK.Controls.Add(this.textBoxAddressK);
            this.groupBoxInfoK.Enabled = false;
            this.groupBoxInfoK.Location = new System.Drawing.Point(15, 92);
            this.groupBoxInfoK.Name = "groupBoxInfoK";
            this.groupBoxInfoK.Size = new System.Drawing.Size(342, 98);
            this.groupBoxInfoK.TabIndex = 5;
            this.groupBoxInfoK.TabStop = false;
            this.groupBoxInfoK.Text = "Codice Ricevuto";
            // 
            // pictureBoxOnCodeEnter
            // 
            this.pictureBoxOnCodeEnter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxOnCodeEnter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxOnCodeEnter.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxOnCodeEnter.Location = new System.Drawing.Point(310, 72);
            this.pictureBoxOnCodeEnter.Name = "pictureBoxOnCodeEnter";
            this.pictureBoxOnCodeEnter.Size = new System.Drawing.Size(26, 18);
            this.pictureBoxOnCodeEnter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxOnCodeEnter.TabIndex = 8;
            this.pictureBoxOnCodeEnter.TabStop = false;
            // 
            // labelTecnologyK
            // 
            this.labelTecnologyK.AutoSize = true;
            this.labelTecnologyK.Location = new System.Drawing.Point(83, 49);
            this.labelTecnologyK.Name = "labelTecnologyK";
            this.labelTecnologyK.Size = new System.Drawing.Size(60, 13);
            this.labelTecnologyK.TabIndex = 7;
            this.labelTecnologyK.Text = "Tecnologia";
            // 
            // labelResourceK
            // 
            this.labelResourceK.AutoSize = true;
            this.labelResourceK.Location = new System.Drawing.Point(101, 75);
            this.labelResourceK.Name = "labelResourceK";
            this.labelResourceK.Size = new System.Drawing.Size(42, 13);
            this.labelResourceK.TabIndex = 6;
            this.labelResourceK.Text = "Risorsa";
            // 
            // labelValueK
            // 
            this.labelValueK.AutoSize = true;
            this.labelValueK.Location = new System.Drawing.Point(106, 24);
            this.labelValueK.Name = "labelValueK";
            this.labelValueK.Size = new System.Drawing.Size(37, 13);
            this.labelValueK.TabIndex = 5;
            this.labelValueK.Text = "Valore";
            // 
            // labelAddressK
            // 
            this.labelAddressK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelAddressK.AutoSize = true;
            this.labelAddressK.Location = new System.Drawing.Point(8, 33);
            this.labelAddressK.Name = "labelAddressK";
            this.labelAddressK.Size = new System.Drawing.Size(45, 13);
            this.labelAddressK.TabIndex = 4;
            this.labelAddressK.Text = "Indirizzo";
            // 
            // textBoxTecnologyK
            // 
            this.textBoxTecnologyK.Location = new System.Drawing.Point(144, 46);
            this.textBoxTecnologyK.Name = "textBoxTecnologyK";
            this.textBoxTecnologyK.Size = new System.Drawing.Size(149, 20);
            this.textBoxTecnologyK.TabIndex = 3;
            // 
            // textBoxResourceK
            // 
            this.textBoxResourceK.Location = new System.Drawing.Point(143, 72);
            this.textBoxResourceK.Name = "textBoxResourceK";
            this.textBoxResourceK.Size = new System.Drawing.Size(150, 20);
            this.textBoxResourceK.TabIndex = 2;
            // 
            // textBoxValueK
            // 
            this.textBoxValueK.Location = new System.Drawing.Point(143, 21);
            this.textBoxValueK.Name = "textBoxValueK";
            this.textBoxValueK.Size = new System.Drawing.Size(149, 20);
            this.textBoxValueK.TabIndex = 1;
            // 
            // textBoxAddressK
            // 
            this.textBoxAddressK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxAddressK.Location = new System.Drawing.Point(7, 49);
            this.textBoxAddressK.Name = "textBoxAddressK";
            this.textBoxAddressK.Size = new System.Drawing.Size(45, 20);
            this.textBoxAddressK.TabIndex = 0;
            this.textBoxAddressK.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBoxLed_Buzzer
            // 
            this.groupBoxLed_Buzzer.Controls.Add(this.labelOnLedAndBuzzerSent);
            this.groupBoxLed_Buzzer.Controls.Add(this.pictureBoxOnUpdateLed_Buzzer);
            this.groupBoxLed_Buzzer.Controls.Add(this.labelAddressLed_Buzzer);
            this.groupBoxLed_Buzzer.Controls.Add(this.groupBoxAdvancedLed);
            this.groupBoxLed_Buzzer.Controls.Add(this.numericUpDownAddressLed_Buzzer);
            this.groupBoxLed_Buzzer.Controls.Add(this.buttonUpdate_Buzzer);
            this.groupBoxLed_Buzzer.Controls.Add(this.buttonUpdateLed);
            this.groupBoxLed_Buzzer.Enabled = false;
            this.groupBoxLed_Buzzer.Location = new System.Drawing.Point(367, 254);
            this.groupBoxLed_Buzzer.MaximumSize = new System.Drawing.Size(370, 180);
            this.groupBoxLed_Buzzer.Name = "groupBoxLed_Buzzer";
            this.groupBoxLed_Buzzer.Size = new System.Drawing.Size(360, 170);
            this.groupBoxLed_Buzzer.TabIndex = 6;
            this.groupBoxLed_Buzzer.TabStop = false;
            this.groupBoxLed_Buzzer.Text = "Led e Buzzer";
            // 
            // labelOnLedAndBuzzerSent
            // 
            this.labelOnLedAndBuzzerSent.AutoSize = true;
            this.labelOnLedAndBuzzerSent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOnLedAndBuzzerSent.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelOnLedAndBuzzerSent.Location = new System.Drawing.Point(306, 64);
            this.labelOnLedAndBuzzerSent.Margin = new System.Windows.Forms.Padding(0);
            this.labelOnLedAndBuzzerSent.Name = "labelOnLedAndBuzzerSent";
            this.labelOnLedAndBuzzerSent.Size = new System.Drawing.Size(47, 16);
            this.labelOnLedAndBuzzerSent.TabIndex = 30;
            this.labelOnLedAndBuzzerSent.Text = "Inviato";
            // 
            // pictureBoxOnUpdateLed_Buzzer
            // 
            this.pictureBoxOnUpdateLed_Buzzer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxOnUpdateLed_Buzzer.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxOnUpdateLed_Buzzer.Location = new System.Drawing.Point(324, 80);
            this.pictureBoxOnUpdateLed_Buzzer.Name = "pictureBoxOnUpdateLed_Buzzer";
            this.pictureBoxOnUpdateLed_Buzzer.Size = new System.Drawing.Size(26, 18);
            this.pictureBoxOnUpdateLed_Buzzer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxOnUpdateLed_Buzzer.TabIndex = 13;
            this.pictureBoxOnUpdateLed_Buzzer.TabStop = false;
            // 
            // labelAddressLed_Buzzer
            // 
            this.labelAddressLed_Buzzer.AutoSize = true;
            this.labelAddressLed_Buzzer.Location = new System.Drawing.Point(14, 16);
            this.labelAddressLed_Buzzer.Name = "labelAddressLed_Buzzer";
            this.labelAddressLed_Buzzer.Size = new System.Drawing.Size(45, 13);
            this.labelAddressLed_Buzzer.TabIndex = 12;
            this.labelAddressLed_Buzzer.Text = "Indirizzo";
            // 
            // groupBoxAdvancedLed
            // 
            this.groupBoxAdvancedLed.Controls.Add(this.checkBoxOk);
            this.groupBoxAdvancedLed.Controls.Add(this.labelOk);
            this.groupBoxAdvancedLed.Controls.Add(this.checkBoxFbk);
            this.groupBoxAdvancedLed.Controls.Add(this.labelFbk);
            this.groupBoxAdvancedLed.Controls.Add(this.checkBoxAux);
            this.groupBoxAdvancedLed.Controls.Add(this.labelAux);
            this.groupBoxAdvancedLed.Controls.Add(this.checkBoxRdy);
            this.groupBoxAdvancedLed.Controls.Add(this.pictureBoxLedOk);
            this.groupBoxAdvancedLed.Controls.Add(this.pictureBoxLedFbk);
            this.groupBoxAdvancedLed.Controls.Add(this.pictureBoxLedAux);
            this.groupBoxAdvancedLed.Controls.Add(this.labelRdy);
            this.groupBoxAdvancedLed.Controls.Add(this.numericUpDownCountLedOk);
            this.groupBoxAdvancedLed.Controls.Add(this.numericUpDownIntervalLedOk);
            this.groupBoxAdvancedLed.Controls.Add(this.pictureBoxLedRdy);
            this.groupBoxAdvancedLed.Controls.Add(this.numericUpDownCountLedFbk);
            this.groupBoxAdvancedLed.Controls.Add(this.numericUpDownIntervalLedFbk);
            this.groupBoxAdvancedLed.Controls.Add(this.numericUpDownCountLedAux);
            this.groupBoxAdvancedLed.Controls.Add(this.numericUpDownIntervalLedAux);
            this.groupBoxAdvancedLed.Controls.Add(this.numericUpDownValueBuzzer);
            this.groupBoxAdvancedLed.Controls.Add(this.labelValueBuz);
            this.groupBoxAdvancedLed.Controls.Add(this.numericUpDownIntervalBuzzer);
            this.groupBoxAdvancedLed.Controls.Add(this.labelCountLed);
            this.groupBoxAdvancedLed.Controls.Add(this.labelIntervalLed);
            this.groupBoxAdvancedLed.Controls.Add(this.numericUpDownCountLedRdy);
            this.groupBoxAdvancedLed.Controls.Add(this.numericUpDownIntervalLedRdy);
            this.groupBoxAdvancedLed.Location = new System.Drawing.Point(65, 16);
            this.groupBoxAdvancedLed.Name = "groupBoxAdvancedLed";
            this.groupBoxAdvancedLed.Size = new System.Drawing.Size(196, 147);
            this.groupBoxAdvancedLed.TabIndex = 11;
            this.groupBoxAdvancedLed.TabStop = false;
            this.groupBoxAdvancedLed.Text = "Parametri";
            // 
            // checkBoxOk
            // 
            this.checkBoxOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxOk.AutoSize = true;
            this.checkBoxOk.Checked = true;
            this.checkBoxOk.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxOk.Location = new System.Drawing.Point(36, 98);
            this.checkBoxOk.Margin = new System.Windows.Forms.Padding(1);
            this.checkBoxOk.Name = "checkBoxOk";
            this.checkBoxOk.Padding = new System.Windows.Forms.Padding(1);
            this.checkBoxOk.Size = new System.Drawing.Size(17, 16);
            this.checkBoxOk.TabIndex = 39;
            this.checkBoxOk.UseVisualStyleBackColor = true;
            // 
            // labelOk
            // 
            this.labelOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelOk.AutoSize = true;
            this.labelOk.Location = new System.Drawing.Point(6, 99);
            this.labelOk.Margin = new System.Windows.Forms.Padding(3);
            this.labelOk.Name = "labelOk";
            this.labelOk.Size = new System.Drawing.Size(21, 13);
            this.labelOk.TabIndex = 38;
            this.labelOk.Text = "Ok";
            // 
            // checkBoxFbk
            // 
            this.checkBoxFbk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxFbk.AutoSize = true;
            this.checkBoxFbk.Checked = true;
            this.checkBoxFbk.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxFbk.Location = new System.Drawing.Point(36, 78);
            this.checkBoxFbk.Margin = new System.Windows.Forms.Padding(1);
            this.checkBoxFbk.Name = "checkBoxFbk";
            this.checkBoxFbk.Padding = new System.Windows.Forms.Padding(1);
            this.checkBoxFbk.Size = new System.Drawing.Size(17, 16);
            this.checkBoxFbk.TabIndex = 37;
            this.checkBoxFbk.UseVisualStyleBackColor = true;
            // 
            // labelFbk
            // 
            this.labelFbk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelFbk.AutoSize = true;
            this.labelFbk.Location = new System.Drawing.Point(6, 79);
            this.labelFbk.Margin = new System.Windows.Forms.Padding(3);
            this.labelFbk.Name = "labelFbk";
            this.labelFbk.Size = new System.Drawing.Size(25, 13);
            this.labelFbk.TabIndex = 36;
            this.labelFbk.Text = "Fbk";
            // 
            // checkBoxAux
            // 
            this.checkBoxAux.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxAux.AutoSize = true;
            this.checkBoxAux.Checked = true;
            this.checkBoxAux.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAux.Location = new System.Drawing.Point(36, 58);
            this.checkBoxAux.Margin = new System.Windows.Forms.Padding(1);
            this.checkBoxAux.Name = "checkBoxAux";
            this.checkBoxAux.Padding = new System.Windows.Forms.Padding(1);
            this.checkBoxAux.Size = new System.Drawing.Size(17, 16);
            this.checkBoxAux.TabIndex = 35;
            this.checkBoxAux.UseVisualStyleBackColor = true;
            // 
            // labelAux
            // 
            this.labelAux.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelAux.AutoSize = true;
            this.labelAux.Location = new System.Drawing.Point(6, 59);
            this.labelAux.Margin = new System.Windows.Forms.Padding(3);
            this.labelAux.Name = "labelAux";
            this.labelAux.Size = new System.Drawing.Size(25, 13);
            this.labelAux.TabIndex = 34;
            this.labelAux.Text = "Aux";
            // 
            // checkBoxRdy
            // 
            this.checkBoxRdy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxRdy.AutoSize = true;
            this.checkBoxRdy.Location = new System.Drawing.Point(36, 36);
            this.checkBoxRdy.Margin = new System.Windows.Forms.Padding(1);
            this.checkBoxRdy.Name = "checkBoxRdy";
            this.checkBoxRdy.Padding = new System.Windows.Forms.Padding(1);
            this.checkBoxRdy.Size = new System.Drawing.Size(17, 16);
            this.checkBoxRdy.TabIndex = 33;
            this.checkBoxRdy.UseVisualStyleBackColor = true;
            // 
            // pictureBoxLedOk
            // 
            this.pictureBoxLedOk.Image = global::DemoPlexaNetK.Properties.Resources.LedLGreenK;
            this.pictureBoxLedOk.Location = new System.Drawing.Point(55, 98);
            this.pictureBoxLedOk.Name = "pictureBoxLedOk";
            this.pictureBoxLedOk.Size = new System.Drawing.Size(16, 14);
            this.pictureBoxLedOk.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxLedOk.TabIndex = 19;
            this.pictureBoxLedOk.TabStop = false;
            // 
            // pictureBoxLedFbk
            // 
            this.pictureBoxLedFbk.Image = global::DemoPlexaNetK.Properties.Resources.LedLYellowK;
            this.pictureBoxLedFbk.Location = new System.Drawing.Point(57, 78);
            this.pictureBoxLedFbk.Name = "pictureBoxLedFbk";
            this.pictureBoxLedFbk.Size = new System.Drawing.Size(14, 13);
            this.pictureBoxLedFbk.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxLedFbk.TabIndex = 18;
            this.pictureBoxLedFbk.TabStop = false;
            // 
            // pictureBoxLedAux
            // 
            this.pictureBoxLedAux.Image = global::DemoPlexaNetK.Properties.Resources.LedLRedK;
            this.pictureBoxLedAux.Location = new System.Drawing.Point(57, 59);
            this.pictureBoxLedAux.Name = "pictureBoxLedAux";
            this.pictureBoxLedAux.Size = new System.Drawing.Size(14, 14);
            this.pictureBoxLedAux.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxLedAux.TabIndex = 17;
            this.pictureBoxLedAux.TabStop = false;
            // 
            // labelRdy
            // 
            this.labelRdy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelRdy.AutoSize = true;
            this.labelRdy.Location = new System.Drawing.Point(6, 37);
            this.labelRdy.Margin = new System.Windows.Forms.Padding(3);
            this.labelRdy.Name = "labelRdy";
            this.labelRdy.Size = new System.Drawing.Size(26, 13);
            this.labelRdy.TabIndex = 23;
            this.labelRdy.Text = "Rdy";
            // 
            // numericUpDownCountLedOk
            // 
            this.numericUpDownCountLedOk.Location = new System.Drawing.Point(89, 92);
            this.numericUpDownCountLedOk.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.numericUpDownCountLedOk.Name = "numericUpDownCountLedOk";
            this.numericUpDownCountLedOk.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownCountLedOk.TabIndex = 22;
            this.numericUpDownCountLedOk.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDownIntervalLedOk
            // 
            this.numericUpDownIntervalLedOk.Location = new System.Drawing.Point(154, 92);
            this.numericUpDownIntervalLedOk.Name = "numericUpDownIntervalLedOk";
            this.numericUpDownIntervalLedOk.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownIntervalLedOk.TabIndex = 21;
            this.numericUpDownIntervalLedOk.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // pictureBoxLedRdy
            // 
            this.pictureBoxLedRdy.Image = global::DemoPlexaNetK.Properties.Resources.LedLBlueK;
            this.pictureBoxLedRdy.InitialImage = null;
            this.pictureBoxLedRdy.Location = new System.Drawing.Point(57, 37);
            this.pictureBoxLedRdy.Name = "pictureBoxLedRdy";
            this.pictureBoxLedRdy.Size = new System.Drawing.Size(13, 13);
            this.pictureBoxLedRdy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxLedRdy.TabIndex = 14;
            this.pictureBoxLedRdy.TabStop = false;
            // 
            // numericUpDownCountLedFbk
            // 
            this.numericUpDownCountLedFbk.Location = new System.Drawing.Point(89, 72);
            this.numericUpDownCountLedFbk.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.numericUpDownCountLedFbk.Name = "numericUpDownCountLedFbk";
            this.numericUpDownCountLedFbk.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownCountLedFbk.TabIndex = 20;
            this.numericUpDownCountLedFbk.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDownIntervalLedFbk
            // 
            this.numericUpDownIntervalLedFbk.Location = new System.Drawing.Point(154, 72);
            this.numericUpDownIntervalLedFbk.Name = "numericUpDownIntervalLedFbk";
            this.numericUpDownIntervalLedFbk.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownIntervalLedFbk.TabIndex = 19;
            this.numericUpDownIntervalLedFbk.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // numericUpDownCountLedAux
            // 
            this.numericUpDownCountLedAux.Location = new System.Drawing.Point(89, 52);
            this.numericUpDownCountLedAux.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.numericUpDownCountLedAux.Name = "numericUpDownCountLedAux";
            this.numericUpDownCountLedAux.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownCountLedAux.TabIndex = 18;
            this.numericUpDownCountLedAux.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDownIntervalLedAux
            // 
            this.numericUpDownIntervalLedAux.Location = new System.Drawing.Point(154, 52);
            this.numericUpDownIntervalLedAux.Name = "numericUpDownIntervalLedAux";
            this.numericUpDownIntervalLedAux.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownIntervalLedAux.TabIndex = 17;
            this.numericUpDownIntervalLedAux.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDownValueBuzzer
            // 
            this.numericUpDownValueBuzzer.Location = new System.Drawing.Point(89, 120);
            this.numericUpDownValueBuzzer.Maximum = new decimal(new int[] {
            13,
            0,
            0,
            0});
            this.numericUpDownValueBuzzer.Name = "numericUpDownValueBuzzer";
            this.numericUpDownValueBuzzer.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownValueBuzzer.TabIndex = 15;
            this.numericUpDownValueBuzzer.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // labelValueBuz
            // 
            this.labelValueBuz.AutoSize = true;
            this.labelValueBuz.Location = new System.Drawing.Point(56, 123);
            this.labelValueBuz.Name = "labelValueBuz";
            this.labelValueBuz.Size = new System.Drawing.Size(32, 13);
            this.labelValueBuz.TabIndex = 14;
            this.labelValueBuz.Text = "Tono";
            // 
            // numericUpDownIntervalBuzzer
            // 
            this.numericUpDownIntervalBuzzer.Location = new System.Drawing.Point(155, 120);
            this.numericUpDownIntervalBuzzer.Name = "numericUpDownIntervalBuzzer";
            this.numericUpDownIntervalBuzzer.Size = new System.Drawing.Size(35, 20);
            this.numericUpDownIntervalBuzzer.TabIndex = 13;
            this.numericUpDownIntervalBuzzer.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // labelCountLed
            // 
            this.labelCountLed.AutoSize = true;
            this.labelCountLed.Location = new System.Drawing.Point(65, 18);
            this.labelCountLed.Name = "labelCountLed";
            this.labelCountLed.Size = new System.Drawing.Size(72, 13);
            this.labelCountLed.TabIndex = 12;
            this.labelCountLed.Text = "Commutazioni";
            // 
            // labelIntervalLed
            // 
            this.labelIntervalLed.AutoSize = true;
            this.labelIntervalLed.Location = new System.Drawing.Point(140, 18);
            this.labelIntervalLed.Name = "labelIntervalLed";
            this.labelIntervalLed.Size = new System.Drawing.Size(50, 13);
            this.labelIntervalLed.TabIndex = 11;
            this.labelIntervalLed.Text = "Intervallo";
            // 
            // numericUpDownCountLedRdy
            // 
            this.numericUpDownCountLedRdy.Location = new System.Drawing.Point(89, 32);
            this.numericUpDownCountLedRdy.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.numericUpDownCountLedRdy.Name = "numericUpDownCountLedRdy";
            this.numericUpDownCountLedRdy.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownCountLedRdy.TabIndex = 10;
            this.numericUpDownCountLedRdy.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // numericUpDownIntervalLedRdy
            // 
            this.numericUpDownIntervalLedRdy.Location = new System.Drawing.Point(154, 32);
            this.numericUpDownIntervalLedRdy.Name = "numericUpDownIntervalLedRdy";
            this.numericUpDownIntervalLedRdy.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownIntervalLedRdy.TabIndex = 9;
            this.numericUpDownIntervalLedRdy.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // numericUpDownAddressLed_Buzzer
            // 
            this.numericUpDownAddressLed_Buzzer.Location = new System.Drawing.Point(17, 32);
            this.numericUpDownAddressLed_Buzzer.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.numericUpDownAddressLed_Buzzer.Name = "numericUpDownAddressLed_Buzzer";
            this.numericUpDownAddressLed_Buzzer.Size = new System.Drawing.Size(42, 20);
            this.numericUpDownAddressLed_Buzzer.TabIndex = 8;
            this.numericUpDownAddressLed_Buzzer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownAddressLed_Buzzer.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // buttonUpdate_Buzzer
            // 
            this.buttonUpdate_Buzzer.Location = new System.Drawing.Point(278, 136);
            this.buttonUpdate_Buzzer.Margin = new System.Windows.Forms.Padding(0);
            this.buttonUpdate_Buzzer.Name = "buttonUpdate_Buzzer";
            this.buttonUpdate_Buzzer.Size = new System.Drawing.Size(62, 22);
            this.buttonUpdate_Buzzer.TabIndex = 1;
            this.buttonUpdate_Buzzer.Text = "Buzzer";
            this.buttonUpdate_Buzzer.UseVisualStyleBackColor = true;
            this.buttonUpdate_Buzzer.Click += new System.EventHandler(this.buttonUpdate_Buzzer_Click);
            // 
            // buttonUpdateLed
            // 
            this.buttonUpdateLed.Location = new System.Drawing.Point(278, 105);
            this.buttonUpdateLed.Name = "buttonUpdateLed";
            this.buttonUpdateLed.Size = new System.Drawing.Size(62, 22);
            this.buttonUpdateLed.TabIndex = 0;
            this.buttonUpdateLed.Text = "Led";
            this.buttonUpdateLed.UseVisualStyleBackColor = true;
            this.buttonUpdateLed.Click += new System.EventHandler(this.buttonUpdateLed_Click);
            // 
            // groupBoxPulser
            // 
            this.groupBoxPulser.Controls.Add(this.labelOnPulserSent);
            this.groupBoxPulser.Controls.Add(this.numericUpDownResourcePulser);
            this.groupBoxPulser.Controls.Add(this.labelResourcePulser);
            this.groupBoxPulser.Controls.Add(this.numericUpDownValuePulser);
            this.groupBoxPulser.Controls.Add(this.labelValuePulser);
            this.groupBoxPulser.Controls.Add(this.buttonUpdatePulser);
            this.groupBoxPulser.Controls.Add(this.pictureBoxOnPulserUpdate);
            this.groupBoxPulser.Controls.Add(this.labelAddressPulser);
            this.groupBoxPulser.Controls.Add(this.groupBoxAdvancedPulser);
            this.groupBoxPulser.Controls.Add(this.pictureBoxOnPulserRead);
            this.groupBoxPulser.Controls.Add(this.numericUpDownAddressPulser);
            this.groupBoxPulser.Controls.Add(this.buttonPulserRead);
            this.groupBoxPulser.Enabled = false;
            this.groupBoxPulser.Location = new System.Drawing.Point(367, 425);
            this.groupBoxPulser.MaximumSize = new System.Drawing.Size(370, 137);
            this.groupBoxPulser.Name = "groupBoxPulser";
            this.groupBoxPulser.Size = new System.Drawing.Size(360, 134);
            this.groupBoxPulser.TabIndex = 7;
            this.groupBoxPulser.TabStop = false;
            this.groupBoxPulser.Text = "Pulser";
            // 
            // labelOnPulserSent
            // 
            this.labelOnPulserSent.AutoSize = true;
            this.labelOnPulserSent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOnPulserSent.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelOnPulserSent.Location = new System.Drawing.Point(302, 111);
            this.labelOnPulserSent.Margin = new System.Windows.Forms.Padding(0);
            this.labelOnPulserSent.Name = "labelOnPulserSent";
            this.labelOnPulserSent.Size = new System.Drawing.Size(47, 16);
            this.labelOnPulserSent.TabIndex = 28;
            this.labelOnPulserSent.Text = "Inviato";
            // 
            // numericUpDownResourcePulser
            // 
            this.numericUpDownResourcePulser.Location = new System.Drawing.Point(74, 32);
            this.numericUpDownResourcePulser.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.numericUpDownResourcePulser.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownResourcePulser.Name = "numericUpDownResourcePulser";
            this.numericUpDownResourcePulser.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownResourcePulser.TabIndex = 27;
            this.numericUpDownResourcePulser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownResourcePulser.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // labelResourcePulser
            // 
            this.labelResourcePulser.AutoSize = true;
            this.labelResourcePulser.Location = new System.Drawing.Point(71, 16);
            this.labelResourcePulser.Name = "labelResourcePulser";
            this.labelResourcePulser.Size = new System.Drawing.Size(42, 13);
            this.labelResourcePulser.TabIndex = 26;
            this.labelResourcePulser.Text = "Risorsa";
            // 
            // numericUpDownValuePulser
            // 
            this.numericUpDownValuePulser.Location = new System.Drawing.Point(140, 32);
            this.numericUpDownValuePulser.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownValuePulser.Name = "numericUpDownValuePulser";
            this.numericUpDownValuePulser.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownValuePulser.TabIndex = 25;
            this.numericUpDownValuePulser.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // labelValuePulser
            // 
            this.labelValuePulser.AutoSize = true;
            this.labelValuePulser.Location = new System.Drawing.Point(139, 16);
            this.labelValuePulser.Name = "labelValuePulser";
            this.labelValuePulser.Size = new System.Drawing.Size(37, 13);
            this.labelValuePulser.TabIndex = 24;
            this.labelValuePulser.Text = "Valore";
            // 
            // buttonUpdatePulser
            // 
            this.buttonUpdatePulser.Location = new System.Drawing.Point(253, 88);
            this.buttonUpdatePulser.Margin = new System.Windows.Forms.Padding(1);
            this.buttonUpdatePulser.Name = "buttonUpdatePulser";
            this.buttonUpdatePulser.Size = new System.Drawing.Size(62, 22);
            this.buttonUpdatePulser.TabIndex = 0;
            this.buttonUpdatePulser.Text = "Attiva";
            this.buttonUpdatePulser.UseVisualStyleBackColor = true;
            this.buttonUpdatePulser.Click += new System.EventHandler(this.buttonUpdatePulser_Click);
            // 
            // pictureBoxOnPulserUpdate
            // 
            this.pictureBoxOnPulserUpdate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxOnPulserUpdate.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxOnPulserUpdate.Location = new System.Drawing.Point(323, 90);
            this.pictureBoxOnPulserUpdate.Name = "pictureBoxOnPulserUpdate";
            this.pictureBoxOnPulserUpdate.Size = new System.Drawing.Size(26, 18);
            this.pictureBoxOnPulserUpdate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxOnPulserUpdate.TabIndex = 22;
            this.pictureBoxOnPulserUpdate.TabStop = false;
            // 
            // labelAddressPulser
            // 
            this.labelAddressPulser.AutoSize = true;
            this.labelAddressPulser.Location = new System.Drawing.Point(14, 16);
            this.labelAddressPulser.Name = "labelAddressPulser";
            this.labelAddressPulser.Size = new System.Drawing.Size(45, 13);
            this.labelAddressPulser.TabIndex = 14;
            this.labelAddressPulser.Text = "Indirizzo";
            // 
            // groupBoxAdvancedPulser
            // 
            this.groupBoxAdvancedPulser.Controls.Add(this.labelCountPulser);
            this.groupBoxAdvancedPulser.Controls.Add(this.labelIntervalPulser);
            this.groupBoxAdvancedPulser.Controls.Add(this.numericUpDownCountPulser);
            this.groupBoxAdvancedPulser.Controls.Add(this.numericUpDownIntervalPulser);
            this.groupBoxAdvancedPulser.Location = new System.Drawing.Point(6, 72);
            this.groupBoxAdvancedPulser.Name = "groupBoxAdvancedPulser";
            this.groupBoxAdvancedPulser.Size = new System.Drawing.Size(217, 47);
            this.groupBoxAdvancedPulser.TabIndex = 16;
            this.groupBoxAdvancedPulser.TabStop = false;
            this.groupBoxAdvancedPulser.Text = "Parametri";
            // 
            // labelCountPulser
            // 
            this.labelCountPulser.AutoSize = true;
            this.labelCountPulser.Location = new System.Drawing.Point(6, 21);
            this.labelCountPulser.Name = "labelCountPulser";
            this.labelCountPulser.Size = new System.Drawing.Size(72, 13);
            this.labelCountPulser.TabIndex = 12;
            this.labelCountPulser.Text = "Commutazioni";
            // 
            // labelIntervalPulser
            // 
            this.labelIntervalPulser.AutoSize = true;
            this.labelIntervalPulser.Location = new System.Drawing.Point(120, 21);
            this.labelIntervalPulser.Name = "labelIntervalPulser";
            this.labelIntervalPulser.Size = new System.Drawing.Size(50, 13);
            this.labelIntervalPulser.TabIndex = 11;
            this.labelIntervalPulser.Text = "Intervallo";
            // 
            // numericUpDownCountPulser
            // 
            this.numericUpDownCountPulser.Location = new System.Drawing.Point(84, 16);
            this.numericUpDownCountPulser.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.numericUpDownCountPulser.Name = "numericUpDownCountPulser";
            this.numericUpDownCountPulser.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownCountPulser.TabIndex = 10;
            this.numericUpDownCountPulser.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDownIntervalPulser
            // 
            this.numericUpDownIntervalPulser.Location = new System.Drawing.Point(172, 16);
            this.numericUpDownIntervalPulser.Name = "numericUpDownIntervalPulser";
            this.numericUpDownIntervalPulser.Size = new System.Drawing.Size(36, 20);
            this.numericUpDownIntervalPulser.TabIndex = 9;
            this.numericUpDownIntervalPulser.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pictureBoxOnPulserRead
            // 
            this.pictureBoxOnPulserRead.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxOnPulserRead.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxOnPulserRead.Location = new System.Drawing.Point(323, 61);
            this.pictureBoxOnPulserRead.Name = "pictureBoxOnPulserRead";
            this.pictureBoxOnPulserRead.Size = new System.Drawing.Size(26, 18);
            this.pictureBoxOnPulserRead.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxOnPulserRead.TabIndex = 20;
            this.pictureBoxOnPulserRead.TabStop = false;
            // 
            // numericUpDownAddressPulser
            // 
            this.numericUpDownAddressPulser.Location = new System.Drawing.Point(17, 32);
            this.numericUpDownAddressPulser.Maximum = new decimal(new int[] {
            35,
            0,
            0,
            0});
            this.numericUpDownAddressPulser.Name = "numericUpDownAddressPulser";
            this.numericUpDownAddressPulser.Size = new System.Drawing.Size(42, 20);
            this.numericUpDownAddressPulser.TabIndex = 13;
            this.numericUpDownAddressPulser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownAddressPulser.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // buttonPulserRead
            // 
            this.buttonPulserRead.Location = new System.Drawing.Point(253, 61);
            this.buttonPulserRead.Name = "buttonPulserRead";
            this.buttonPulserRead.Size = new System.Drawing.Size(62, 22);
            this.buttonPulserRead.TabIndex = 1;
            this.buttonPulserRead.Text = "Leggi";
            this.buttonPulserRead.UseVisualStyleBackColor = true;
            this.buttonPulserRead.Click += new System.EventHandler(this.buttonPulserRead_Click);
            // 
            // buttonReadDigitalLevel
            // 
            this.buttonReadDigitalLevel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonReadDigitalLevel.Location = new System.Drawing.Point(221, 28);
            this.buttonReadDigitalLevel.Name = "buttonReadDigitalLevel";
            this.buttonReadDigitalLevel.Size = new System.Drawing.Size(62, 22);
            this.buttonReadDigitalLevel.TabIndex = 18;
            this.buttonReadDigitalLevel.Text = "Leggi";
            this.buttonReadDigitalLevel.UseVisualStyleBackColor = true;
            this.buttonReadDigitalLevel.Click += new System.EventHandler(this.buttonReadDigitalLevel_Click);
            // 
            // textBoxVerbose
            // 
            this.textBoxVerbose.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxVerbose.Location = new System.Drawing.Point(15, 596);
            this.textBoxVerbose.Multiline = true;
            this.textBoxVerbose.Name = "textBoxVerbose";
            this.textBoxVerbose.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxVerbose.Size = new System.Drawing.Size(712, 136);
            this.textBoxVerbose.TabIndex = 11;
            this.textBoxVerbose.Visible = false;
            this.textBoxVerbose.TextChanged += new System.EventHandler(this.textBoxVerbose_TextChanged);
            // 
            // groupBoxTamper
            // 
            this.groupBoxTamper.Controls.Add(this.pictureBoxOnTamperChange);
            this.groupBoxTamper.Controls.Add(this.labelValueTamper);
            this.groupBoxTamper.Controls.Add(this.textBoxValueTamper);
            this.groupBoxTamper.Controls.Add(this.labelAddressTamper);
            this.groupBoxTamper.Controls.Add(this.textBoxAddressTamper);
            this.groupBoxTamper.Enabled = false;
            this.groupBoxTamper.Location = new System.Drawing.Point(15, 417);
            this.groupBoxTamper.Name = "groupBoxTamper";
            this.groupBoxTamper.Size = new System.Drawing.Size(342, 53);
            this.groupBoxTamper.TabIndex = 12;
            this.groupBoxTamper.TabStop = false;
            this.groupBoxTamper.Text = "Tamper";
            // 
            // labelValueTamper
            // 
            this.labelValueTamper.AutoSize = true;
            this.labelValueTamper.Location = new System.Drawing.Point(91, 27);
            this.labelValueTamper.Name = "labelValueTamper";
            this.labelValueTamper.Size = new System.Drawing.Size(37, 13);
            this.labelValueTamper.TabIndex = 27;
            this.labelValueTamper.Text = "Valore";
            // 
            // textBoxValueTamper
            // 
            this.textBoxValueTamper.Location = new System.Drawing.Point(173, 24);
            this.textBoxValueTamper.Name = "textBoxValueTamper";
            this.textBoxValueTamper.Size = new System.Drawing.Size(33, 20);
            this.textBoxValueTamper.TabIndex = 28;
            // 
            // labelAddressTamper
            // 
            this.labelAddressTamper.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelAddressTamper.AutoSize = true;
            this.labelAddressTamper.Location = new System.Drawing.Point(6, 11);
            this.labelAddressTamper.Name = "labelAddressTamper";
            this.labelAddressTamper.Size = new System.Drawing.Size(45, 13);
            this.labelAddressTamper.TabIndex = 27;
            this.labelAddressTamper.Text = "Indirizzo";
            // 
            // textBoxAddressTamper
            // 
            this.textBoxAddressTamper.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxAddressTamper.Location = new System.Drawing.Point(6, 27);
            this.textBoxAddressTamper.Name = "textBoxAddressTamper";
            this.textBoxAddressTamper.Size = new System.Drawing.Size(45, 20);
            this.textBoxAddressTamper.TabIndex = 1;
            // 
            // labelOnError
            // 
            this.labelOnError.AutoSize = true;
            this.labelOnError.Enabled = false;
            this.labelOnError.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOnError.ForeColor = System.Drawing.Color.Red;
            this.labelOnError.Location = new System.Drawing.Point(500, 567);
            this.labelOnError.Name = "labelOnError";
            this.labelOnError.Size = new System.Drawing.Size(67, 22);
            this.labelOnError.TabIndex = 1;
            this.labelOnError.Text = "Error :";
            // 
            // groupBoxDigitalLevel
            // 
            this.groupBoxDigitalLevel.Controls.Add(this.numericUpDownResourceDigitalLevel);
            this.groupBoxDigitalLevel.Controls.Add(this.labelResourceReadDigitalLevel);
            this.groupBoxDigitalLevel.Controls.Add(this.labelValueDigitalLevel);
            this.groupBoxDigitalLevel.Controls.Add(this.textBoxValueDigitalLevel);
            this.groupBoxDigitalLevel.Controls.Add(this.labelAddressDigitalLevel);
            this.groupBoxDigitalLevel.Controls.Add(this.numericUpDownAddressDigitalLevel);
            this.groupBoxDigitalLevel.Controls.Add(this.pictureBoxOnDigitalLevel);
            this.groupBoxDigitalLevel.Controls.Add(this.buttonReadDigitalLevel);
            this.groupBoxDigitalLevel.Enabled = false;
            this.groupBoxDigitalLevel.Location = new System.Drawing.Point(15, 304);
            this.groupBoxDigitalLevel.Name = "groupBoxDigitalLevel";
            this.groupBoxDigitalLevel.Size = new System.Drawing.Size(342, 57);
            this.groupBoxDigitalLevel.TabIndex = 13;
            this.groupBoxDigitalLevel.TabStop = false;
            this.groupBoxDigitalLevel.Text = "Input Digitale";
            // 
            // numericUpDownResourceDigitalLevel
            // 
            this.numericUpDownResourceDigitalLevel.Location = new System.Drawing.Point(60, 31);
            this.numericUpDownResourceDigitalLevel.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numericUpDownResourceDigitalLevel.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownResourceDigitalLevel.Name = "numericUpDownResourceDigitalLevel";
            this.numericUpDownResourceDigitalLevel.Size = new System.Drawing.Size(40, 20);
            this.numericUpDownResourceDigitalLevel.TabIndex = 27;
            this.numericUpDownResourceDigitalLevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownResourceDigitalLevel.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // labelResourceReadDigitalLevel
            // 
            this.labelResourceReadDigitalLevel.AutoSize = true;
            this.labelResourceReadDigitalLevel.Location = new System.Drawing.Point(57, 16);
            this.labelResourceReadDigitalLevel.Name = "labelResourceReadDigitalLevel";
            this.labelResourceReadDigitalLevel.Size = new System.Drawing.Size(42, 13);
            this.labelResourceReadDigitalLevel.TabIndex = 26;
            this.labelResourceReadDigitalLevel.Text = "Risorsa";
            // 
            // labelValueDigitalLevel
            // 
            this.labelValueDigitalLevel.AutoSize = true;
            this.labelValueDigitalLevel.Location = new System.Drawing.Point(109, 16);
            this.labelValueDigitalLevel.Name = "labelValueDigitalLevel";
            this.labelValueDigitalLevel.Size = new System.Drawing.Size(37, 13);
            this.labelValueDigitalLevel.TabIndex = 25;
            this.labelValueDigitalLevel.Text = "Valore";
            // 
            // textBoxValueDigitalLevel
            // 
            this.textBoxValueDigitalLevel.Location = new System.Drawing.Point(113, 31);
            this.textBoxValueDigitalLevel.Name = "textBoxValueDigitalLevel";
            this.textBoxValueDigitalLevel.Size = new System.Drawing.Size(33, 20);
            this.textBoxValueDigitalLevel.TabIndex = 24;
            // 
            // labelAddressDigitalLevel
            // 
            this.labelAddressDigitalLevel.AutoSize = true;
            this.labelAddressDigitalLevel.Location = new System.Drawing.Point(5, 16);
            this.labelAddressDigitalLevel.Name = "labelAddressDigitalLevel";
            this.labelAddressDigitalLevel.Size = new System.Drawing.Size(45, 13);
            this.labelAddressDigitalLevel.TabIndex = 23;
            this.labelAddressDigitalLevel.Text = "Indirizzo";
            // 
            // numericUpDownAddressDigitalLevel
            // 
            this.numericUpDownAddressDigitalLevel.Location = new System.Drawing.Point(7, 31);
            this.numericUpDownAddressDigitalLevel.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.numericUpDownAddressDigitalLevel.Name = "numericUpDownAddressDigitalLevel";
            this.numericUpDownAddressDigitalLevel.Size = new System.Drawing.Size(42, 20);
            this.numericUpDownAddressDigitalLevel.TabIndex = 21;
            this.numericUpDownAddressDigitalLevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownAddressDigitalLevel.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pictureBoxOnDigitalLevel
            // 
            this.pictureBoxOnDigitalLevel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxOnDigitalLevel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxOnDigitalLevel.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxOnDigitalLevel.Location = new System.Drawing.Point(310, 31);
            this.pictureBoxOnDigitalLevel.Name = "pictureBoxOnDigitalLevel";
            this.pictureBoxOnDigitalLevel.Size = new System.Drawing.Size(26, 18);
            this.pictureBoxOnDigitalLevel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxOnDigitalLevel.TabIndex = 21;
            this.pictureBoxOnDigitalLevel.TabStop = false;
            // 
            // groupBoxKeyEnter
            // 
            this.groupBoxKeyEnter.Controls.Add(this.pictureBoxOnKeyEnter);
            this.groupBoxKeyEnter.Controls.Add(this.labelKeyEnterValue);
            this.groupBoxKeyEnter.Controls.Add(this.textBoxValueKey);
            this.groupBoxKeyEnter.Controls.Add(this.labelAddressKey);
            this.groupBoxKeyEnter.Controls.Add(this.textBoxAddressKey);
            this.groupBoxKeyEnter.Enabled = false;
            this.groupBoxKeyEnter.Location = new System.Drawing.Point(15, 362);
            this.groupBoxKeyEnter.Name = "groupBoxKeyEnter";
            this.groupBoxKeyEnter.Size = new System.Drawing.Size(342, 54);
            this.groupBoxKeyEnter.TabIndex = 14;
            this.groupBoxKeyEnter.TabStop = false;
            this.groupBoxKeyEnter.Text = "Tastiera";
            // 
            // labelKeyEnterValue
            // 
            this.labelKeyEnterValue.AutoSize = true;
            this.labelKeyEnterValue.Location = new System.Drawing.Point(91, 27);
            this.labelKeyEnterValue.Name = "labelKeyEnterValue";
            this.labelKeyEnterValue.Size = new System.Drawing.Size(76, 13);
            this.labelKeyEnterValue.TabIndex = 26;
            this.labelKeyEnterValue.Text = "Tasto Premuto";
            // 
            // textBoxValueKey
            // 
            this.textBoxValueKey.Location = new System.Drawing.Point(173, 24);
            this.textBoxValueKey.Name = "textBoxValueKey";
            this.textBoxValueKey.Size = new System.Drawing.Size(33, 20);
            this.textBoxValueKey.TabIndex = 25;
            // 
            // labelAddressKey
            // 
            this.labelAddressKey.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelAddressKey.AutoSize = true;
            this.labelAddressKey.Location = new System.Drawing.Point(7, 14);
            this.labelAddressKey.Name = "labelAddressKey";
            this.labelAddressKey.Size = new System.Drawing.Size(45, 13);
            this.labelAddressKey.TabIndex = 24;
            this.labelAddressKey.Text = "Indirizzo";
            // 
            // textBoxAddressKey
            // 
            this.textBoxAddressKey.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxAddressKey.Location = new System.Drawing.Point(7, 29);
            this.textBoxAddressKey.Name = "textBoxAddressKey";
            this.textBoxAddressKey.Size = new System.Drawing.Size(45, 20);
            this.textBoxAddressKey.TabIndex = 0;
            this.textBoxAddressKey.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelInput
            // 
            this.labelInput.AutoSize = true;
            this.labelInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInput.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelInput.Location = new System.Drawing.Point(11, 71);
            this.labelInput.Name = "labelInput";
            this.labelInput.Size = new System.Drawing.Size(150, 22);
            this.labelInput.TabIndex = 15;
            this.labelInput.Text = "Risorse di Input";
            // 
            // labelOutput
            // 
            this.labelOutput.AutoSize = true;
            this.labelOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOutput.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelOutput.Location = new System.Drawing.Point(363, 71);
            this.labelOutput.Name = "labelOutput";
            this.labelOutput.Size = new System.Drawing.Size(166, 22);
            this.labelOutput.TabIndex = 16;
            this.labelOutput.Text = "Risorse di Output";
            // 
            // checkBoxVerbose
            // 
            this.checkBoxVerbose.AutoSize = true;
            this.checkBoxVerbose.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxVerbose.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.checkBoxVerbose.Location = new System.Drawing.Point(373, 567);
            this.checkBoxVerbose.Name = "checkBoxVerbose";
            this.checkBoxVerbose.Size = new System.Drawing.Size(62, 26);
            this.checkBoxVerbose.TabIndex = 18;
            this.checkBoxVerbose.Text = "Log";
            this.checkBoxVerbose.UseVisualStyleBackColor = true;
            this.checkBoxVerbose.CheckedChanged += new System.EventHandler(this.checkBoxVerbose_CheckedChanged);
            // 
            // timerOnAcknoledgeLed
            // 
            this.timerOnAcknoledgeLed.Interval = 2000;
            this.timerOnAcknoledgeLed.Tick += new System.EventHandler(this.timerOnAcknoledgeLed_Tick);
            // 
            // textBoxErrorDesc
            // 
            this.textBoxErrorDesc.ForeColor = System.Drawing.Color.Red;
            this.textBoxErrorDesc.Location = new System.Drawing.Point(569, 570);
            this.textBoxErrorDesc.Name = "textBoxErrorDesc";
            this.textBoxErrorDesc.Size = new System.Drawing.Size(158, 20);
            this.textBoxErrorDesc.TabIndex = 19;
            // 
            // groupBoxCodeComp
            // 
            this.groupBoxCodeComp.Controls.Add(this.labelCompResourceK);
            this.groupBoxCodeComp.Controls.Add(this.textBoxCompResource);
            this.groupBoxCodeComp.Controls.Add(this.labelCompTeck);
            this.groupBoxCodeComp.Controls.Add(this.pictureBoxOnCodeComp);
            this.groupBoxCodeComp.Controls.Add(this.labelCompSid);
            this.groupBoxCodeComp.Controls.Add(this.textBoxCompTecnology);
            this.groupBoxCodeComp.Controls.Add(this.labelValue2K);
            this.groupBoxCodeComp.Controls.Add(this.textBoxCompSid);
            this.groupBoxCodeComp.Controls.Add(this.labelValue1K);
            this.groupBoxCodeComp.Controls.Add(this.textBoxCompNid);
            this.groupBoxCodeComp.Controls.Add(this.labelCompNid);
            this.groupBoxCodeComp.Controls.Add(this.textBoxCompValue2);
            this.groupBoxCodeComp.Controls.Add(this.textBoxCompValue1);
            this.groupBoxCodeComp.Controls.Add(this.textBoxCompAddress);
            this.groupBoxCodeComp.Controls.Add(this.labelCompAddress);
            this.groupBoxCodeComp.Enabled = false;
            this.groupBoxCodeComp.Location = new System.Drawing.Point(15, 190);
            this.groupBoxCodeComp.Name = "groupBoxCodeComp";
            this.groupBoxCodeComp.Size = new System.Drawing.Size(342, 114);
            this.groupBoxCodeComp.TabIndex = 20;
            this.groupBoxCodeComp.TabStop = false;
            this.groupBoxCodeComp.Text = "Codice Compresso Ricevuto";
            // 
            // labelCompResourceK
            // 
            this.labelCompResourceK.AutoSize = true;
            this.labelCompResourceK.Location = new System.Drawing.Point(84, 94);
            this.labelCompResourceK.Name = "labelCompResourceK";
            this.labelCompResourceK.Size = new System.Drawing.Size(42, 13);
            this.labelCompResourceK.TabIndex = 14;
            this.labelCompResourceK.Text = "Risorsa";
            // 
            // textBoxCompResource
            // 
            this.textBoxCompResource.Location = new System.Drawing.Point(126, 91);
            this.textBoxCompResource.Name = "textBoxCompResource";
            this.textBoxCompResource.Size = new System.Drawing.Size(129, 20);
            this.textBoxCompResource.TabIndex = 13;
            // 
            // labelCompTeck
            // 
            this.labelCompTeck.AutoSize = true;
            this.labelCompTeck.Location = new System.Drawing.Point(66, 71);
            this.labelCompTeck.Name = "labelCompTeck";
            this.labelCompTeck.Size = new System.Drawing.Size(60, 13);
            this.labelCompTeck.TabIndex = 12;
            this.labelCompTeck.Text = "Tecnologia";
            // 
            // pictureBoxOnCodeComp
            // 
            this.pictureBoxOnCodeComp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxOnCodeComp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxOnCodeComp.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxOnCodeComp.Location = new System.Drawing.Point(310, 89);
            this.pictureBoxOnCodeComp.Name = "pictureBoxOnCodeComp";
            this.pictureBoxOnCodeComp.Size = new System.Drawing.Size(26, 18);
            this.pictureBoxOnCodeComp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxOnCodeComp.TabIndex = 11;
            this.pictureBoxOnCodeComp.TabStop = false;
            // 
            // labelCompSid
            // 
            this.labelCompSid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelCompSid.AutoSize = true;
            this.labelCompSid.Location = new System.Drawing.Point(260, 46);
            this.labelCompSid.Name = "labelCompSid";
            this.labelCompSid.Size = new System.Drawing.Size(22, 13);
            this.labelCompSid.TabIndex = 9;
            this.labelCompSid.Text = "Sid";
            // 
            // textBoxCompTecnology
            // 
            this.textBoxCompTecnology.Location = new System.Drawing.Point(126, 68);
            this.textBoxCompTecnology.Name = "textBoxCompTecnology";
            this.textBoxCompTecnology.Size = new System.Drawing.Size(129, 20);
            this.textBoxCompTecnology.TabIndex = 10;
            // 
            // labelValue2K
            // 
            this.labelValue2K.AutoSize = true;
            this.labelValue2K.Location = new System.Drawing.Point(83, 48);
            this.labelValue2K.Name = "labelValue2K";
            this.labelValue2K.Size = new System.Drawing.Size(43, 13);
            this.labelValue2K.TabIndex = 5;
            this.labelValue2K.Text = "Valore2";
            // 
            // textBoxCompSid
            // 
            this.textBoxCompSid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxCompSid.Location = new System.Drawing.Point(283, 43);
            this.textBoxCompSid.Name = "textBoxCompSid";
            this.textBoxCompSid.Size = new System.Drawing.Size(23, 20);
            this.textBoxCompSid.TabIndex = 8;
            // 
            // labelValue1K
            // 
            this.labelValue1K.AutoSize = true;
            this.labelValue1K.Location = new System.Drawing.Point(83, 25);
            this.labelValue1K.Name = "labelValue1K";
            this.labelValue1K.Size = new System.Drawing.Size(43, 13);
            this.labelValue1K.TabIndex = 4;
            this.labelValue1K.Text = "Valore1";
            // 
            // textBoxCompNid
            // 
            this.textBoxCompNid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxCompNid.Location = new System.Drawing.Point(283, 20);
            this.textBoxCompNid.Name = "textBoxCompNid";
            this.textBoxCompNid.Size = new System.Drawing.Size(23, 20);
            this.textBoxCompNid.TabIndex = 6;
            // 
            // labelCompNid
            // 
            this.labelCompNid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelCompNid.AutoSize = true;
            this.labelCompNid.Location = new System.Drawing.Point(259, 22);
            this.labelCompNid.Name = "labelCompNid";
            this.labelCompNid.Size = new System.Drawing.Size(23, 13);
            this.labelCompNid.TabIndex = 7;
            this.labelCompNid.Text = "Nid";
            // 
            // textBoxCompValue2
            // 
            this.textBoxCompValue2.Location = new System.Drawing.Point(126, 45);
            this.textBoxCompValue2.Name = "textBoxCompValue2";
            this.textBoxCompValue2.Size = new System.Drawing.Size(129, 20);
            this.textBoxCompValue2.TabIndex = 1;
            // 
            // textBoxCompValue1
            // 
            this.textBoxCompValue1.Location = new System.Drawing.Point(126, 22);
            this.textBoxCompValue1.Name = "textBoxCompValue1";
            this.textBoxCompValue1.Size = new System.Drawing.Size(129, 20);
            this.textBoxCompValue1.TabIndex = 0;
            // 
            // textBoxCompAddress
            // 
            this.textBoxCompAddress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxCompAddress.Location = new System.Drawing.Point(7, 64);
            this.textBoxCompAddress.Name = "textBoxCompAddress";
            this.textBoxCompAddress.Size = new System.Drawing.Size(45, 20);
            this.textBoxCompAddress.TabIndex = 2;
            this.textBoxCompAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelCompAddress
            // 
            this.labelCompAddress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelCompAddress.AutoSize = true;
            this.labelCompAddress.Location = new System.Drawing.Point(8, 47);
            this.labelCompAddress.Name = "labelCompAddress";
            this.labelCompAddress.Size = new System.Drawing.Size(45, 13);
            this.labelCompAddress.TabIndex = 3;
            this.labelCompAddress.Text = "Indirizzo";
            // 
            // groupBoxCode
            // 
            this.groupBoxCode.Controls.Add(this.labelOnCodeSent);
            this.groupBoxCode.Controls.Add(this.labelAddressCode);
            this.groupBoxCode.Controls.Add(this.pictureBoxOnCodeUpdate);
            this.groupBoxCode.Controls.Add(this.numericUpDownAddressCode);
            this.groupBoxCode.Controls.Add(this.buttonUpdateCode);
            this.groupBoxCode.Controls.Add(this.textBoxCodeValue);
            this.groupBoxCode.Enabled = false;
            this.groupBoxCode.Location = new System.Drawing.Point(367, 96);
            this.groupBoxCode.Name = "groupBoxCode";
            this.groupBoxCode.Size = new System.Drawing.Size(360, 60);
            this.groupBoxCode.TabIndex = 21;
            this.groupBoxCode.TabStop = false;
            this.groupBoxCode.Text = "Invio Codice";
            // 
            // labelOnCodeSent
            // 
            this.labelOnCodeSent.AutoSize = true;
            this.labelOnCodeSent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOnCodeSent.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelOnCodeSent.Location = new System.Drawing.Point(307, 14);
            this.labelOnCodeSent.Name = "labelOnCodeSent";
            this.labelOnCodeSent.Size = new System.Drawing.Size(47, 16);
            this.labelOnCodeSent.TabIndex = 5;
            this.labelOnCodeSent.Text = "Inviato";
            // 
            // labelAddressCode
            // 
            this.labelAddressCode.AutoSize = true;
            this.labelAddressCode.Location = new System.Drawing.Point(14, 17);
            this.labelAddressCode.Name = "labelAddressCode";
            this.labelAddressCode.Size = new System.Drawing.Size(45, 13);
            this.labelAddressCode.TabIndex = 4;
            this.labelAddressCode.Text = "Indirizzo";
            // 
            // pictureBoxOnCodeUpdate
            // 
            this.pictureBoxOnCodeUpdate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxOnCodeUpdate.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxOnCodeUpdate.Location = new System.Drawing.Point(326, 31);
            this.pictureBoxOnCodeUpdate.Name = "pictureBoxOnCodeUpdate";
            this.pictureBoxOnCodeUpdate.Size = new System.Drawing.Size(26, 18);
            this.pictureBoxOnCodeUpdate.TabIndex = 3;
            this.pictureBoxOnCodeUpdate.TabStop = false;
            // 
            // numericUpDownAddressCode
            // 
            this.numericUpDownAddressCode.Location = new System.Drawing.Point(17, 32);
            this.numericUpDownAddressCode.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.numericUpDownAddressCode.Name = "numericUpDownAddressCode";
            this.numericUpDownAddressCode.Size = new System.Drawing.Size(42, 20);
            this.numericUpDownAddressCode.TabIndex = 2;
            this.numericUpDownAddressCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownAddressCode.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // buttonUpdateCode
            // 
            this.buttonUpdateCode.Location = new System.Drawing.Point(224, 31);
            this.buttonUpdateCode.Name = "buttonUpdateCode";
            this.buttonUpdateCode.Size = new System.Drawing.Size(62, 22);
            this.buttonUpdateCode.TabIndex = 1;
            this.buttonUpdateCode.Text = "Invia";
            this.buttonUpdateCode.UseVisualStyleBackColor = true;
            this.buttonUpdateCode.Click += new System.EventHandler(this.buttonUpdateCode_Click);
            // 
            // textBoxCodeValue
            // 
            this.textBoxCodeValue.Location = new System.Drawing.Point(65, 33);
            this.textBoxCodeValue.Name = "textBoxCodeValue";
            this.textBoxCodeValue.Size = new System.Drawing.Size(149, 20);
            this.textBoxCodeValue.TabIndex = 0;
            // 
            // groupBoxParameters
            // 
            this.groupBoxParameters.Controls.Add(this.pictureBoxOnParameters);
            this.groupBoxParameters.Controls.Add(this.groupBoxPar4);
            this.groupBoxParameters.Controls.Add(this.labelAddressParameters);
            this.groupBoxParameters.Controls.Add(this.groupBoxLOCREM);
            this.groupBoxParameters.Controls.Add(this.groupBoxPar3);
            this.groupBoxParameters.Controls.Add(this.groupBoxPar1);
            this.groupBoxParameters.Controls.Add(this.groupBoxPar2);
            this.groupBoxParameters.Controls.Add(this.buttonGetParameters);
            this.groupBoxParameters.Controls.Add(this.numericUpDownParameters);
            this.groupBoxParameters.Enabled = false;
            this.groupBoxParameters.Location = new System.Drawing.Point(15, 470);
            this.groupBoxParameters.Name = "groupBoxParameters";
            this.groupBoxParameters.Size = new System.Drawing.Size(342, 120);
            this.groupBoxParameters.TabIndex = 22;
            this.groupBoxParameters.TabStop = false;
            this.groupBoxParameters.Text = "Parametri";
            // 
            // pictureBoxOnParameters
            // 
            this.pictureBoxOnParameters.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxOnParameters.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxOnParameters.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxOnParameters.Location = new System.Drawing.Point(310, 94);
            this.pictureBoxOnParameters.Name = "pictureBoxOnParameters";
            this.pictureBoxOnParameters.Size = new System.Drawing.Size(26, 18);
            this.pictureBoxOnParameters.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxOnParameters.TabIndex = 29;
            this.pictureBoxOnParameters.TabStop = false;
            // 
            // groupBoxPar4
            // 
            this.groupBoxPar4.Controls.Add(this.radioButtonPar4OFF);
            this.groupBoxPar4.Controls.Add(this.radioButtonPar4ON);
            this.groupBoxPar4.Location = new System.Drawing.Point(258, 13);
            this.groupBoxPar4.Name = "groupBoxPar4";
            this.groupBoxPar4.Size = new System.Drawing.Size(56, 63);
            this.groupBoxPar4.TabIndex = 28;
            this.groupBoxPar4.TabStop = false;
            this.groupBoxPar4.Text = "Par4";
            // 
            // radioButtonPar4OFF
            // 
            this.radioButtonPar4OFF.AutoSize = true;
            this.radioButtonPar4OFF.Location = new System.Drawing.Point(6, 40);
            this.radioButtonPar4OFF.Name = "radioButtonPar4OFF";
            this.radioButtonPar4OFF.Size = new System.Drawing.Size(45, 17);
            this.radioButtonPar4OFF.TabIndex = 1;
            this.radioButtonPar4OFF.TabStop = true;
            this.radioButtonPar4OFF.Text = "OFF";
            this.radioButtonPar4OFF.UseVisualStyleBackColor = true;
            // 
            // radioButtonPar4ON
            // 
            this.radioButtonPar4ON.AutoSize = true;
            this.radioButtonPar4ON.Location = new System.Drawing.Point(6, 19);
            this.radioButtonPar4ON.Name = "radioButtonPar4ON";
            this.radioButtonPar4ON.Size = new System.Drawing.Size(41, 17);
            this.radioButtonPar4ON.TabIndex = 0;
            this.radioButtonPar4ON.TabStop = true;
            this.radioButtonPar4ON.Text = "ON";
            this.radioButtonPar4ON.UseVisualStyleBackColor = true;
            // 
            // labelAddressParameters
            // 
            this.labelAddressParameters.AutoSize = true;
            this.labelAddressParameters.Location = new System.Drawing.Point(6, 81);
            this.labelAddressParameters.Name = "labelAddressParameters";
            this.labelAddressParameters.Size = new System.Drawing.Size(45, 13);
            this.labelAddressParameters.TabIndex = 27;
            this.labelAddressParameters.Text = "Indirizzo";
            // 
            // groupBoxLOCREM
            // 
            this.groupBoxLOCREM.Controls.Add(this.radioButtonDSWLocal);
            this.groupBoxLOCREM.Controls.Add(this.radioButtonDSWRemote);
            this.groupBoxLOCREM.Location = new System.Drawing.Point(5, 13);
            this.groupBoxLOCREM.Name = "groupBoxLOCREM";
            this.groupBoxLOCREM.Size = new System.Drawing.Size(77, 63);
            this.groupBoxLOCREM.TabIndex = 26;
            this.groupBoxLOCREM.TabStop = false;
            this.groupBoxLOCREM.Text = "Controllo";
            // 
            // radioButtonDSWLocal
            // 
            this.radioButtonDSWLocal.AutoSize = true;
            this.radioButtonDSWLocal.Location = new System.Drawing.Point(7, 19);
            this.radioButtonDSWLocal.Name = "radioButtonDSWLocal";
            this.radioButtonDSWLocal.Size = new System.Drawing.Size(57, 17);
            this.radioButtonDSWLocal.TabIndex = 6;
            this.radioButtonDSWLocal.TabStop = true;
            this.radioButtonDSWLocal.Text = "Locale";
            this.radioButtonDSWLocal.UseVisualStyleBackColor = true;
            // 
            // radioButtonDSWRemote
            // 
            this.radioButtonDSWRemote.AutoSize = true;
            this.radioButtonDSWRemote.Location = new System.Drawing.Point(7, 42);
            this.radioButtonDSWRemote.Name = "radioButtonDSWRemote";
            this.radioButtonDSWRemote.Size = new System.Drawing.Size(62, 17);
            this.radioButtonDSWRemote.TabIndex = 7;
            this.radioButtonDSWRemote.TabStop = true;
            this.radioButtonDSWRemote.Text = "Remoto";
            this.radioButtonDSWRemote.UseVisualStyleBackColor = true;
            // 
            // groupBoxPar3
            // 
            this.groupBoxPar3.Controls.Add(this.radioButtonPar3ON);
            this.groupBoxPar3.Controls.Add(this.radioButtonPar3OFF);
            this.groupBoxPar3.Location = new System.Drawing.Point(202, 13);
            this.groupBoxPar3.Name = "groupBoxPar3";
            this.groupBoxPar3.Size = new System.Drawing.Size(56, 63);
            this.groupBoxPar3.TabIndex = 25;
            this.groupBoxPar3.TabStop = false;
            this.groupBoxPar3.Text = "Par3";
            // 
            // radioButtonPar3ON
            // 
            this.radioButtonPar3ON.AutoSize = true;
            this.radioButtonPar3ON.Location = new System.Drawing.Point(6, 19);
            this.radioButtonPar3ON.Name = "radioButtonPar3ON";
            this.radioButtonPar3ON.Size = new System.Drawing.Size(44, 17);
            this.radioButtonPar3ON.TabIndex = 4;
            this.radioButtonPar3ON.TabStop = true;
            this.radioButtonPar3ON.Text = " ON";
            this.radioButtonPar3ON.UseVisualStyleBackColor = true;
            // 
            // radioButtonPar3OFF
            // 
            this.radioButtonPar3OFF.AutoSize = true;
            this.radioButtonPar3OFF.Location = new System.Drawing.Point(6, 40);
            this.radioButtonPar3OFF.Name = "radioButtonPar3OFF";
            this.radioButtonPar3OFF.Size = new System.Drawing.Size(48, 17);
            this.radioButtonPar3OFF.TabIndex = 5;
            this.radioButtonPar3OFF.TabStop = true;
            this.radioButtonPar3OFF.Text = " OFF";
            this.radioButtonPar3OFF.UseVisualStyleBackColor = true;
            // 
            // groupBoxPar1
            // 
            this.groupBoxPar1.Controls.Add(this.radioButtonPar1ON);
            this.groupBoxPar1.Controls.Add(this.radioButtonPar1OFF);
            this.groupBoxPar1.Location = new System.Drawing.Point(90, 13);
            this.groupBoxPar1.Name = "groupBoxPar1";
            this.groupBoxPar1.Size = new System.Drawing.Size(56, 63);
            this.groupBoxPar1.TabIndex = 23;
            this.groupBoxPar1.TabStop = false;
            this.groupBoxPar1.Text = "Par1";
            // 
            // radioButtonPar1ON
            // 
            this.radioButtonPar1ON.AutoSize = true;
            this.radioButtonPar1ON.Location = new System.Drawing.Point(6, 19);
            this.radioButtonPar1ON.Name = "radioButtonPar1ON";
            this.radioButtonPar1ON.Size = new System.Drawing.Size(44, 17);
            this.radioButtonPar1ON.TabIndex = 0;
            this.radioButtonPar1ON.TabStop = true;
            this.radioButtonPar1ON.Text = " ON";
            this.radioButtonPar1ON.UseVisualStyleBackColor = true;
            // 
            // radioButtonPar1OFF
            // 
            this.radioButtonPar1OFF.AutoSize = true;
            this.radioButtonPar1OFF.Location = new System.Drawing.Point(6, 40);
            this.radioButtonPar1OFF.Name = "radioButtonPar1OFF";
            this.radioButtonPar1OFF.Size = new System.Drawing.Size(48, 17);
            this.radioButtonPar1OFF.TabIndex = 1;
            this.radioButtonPar1OFF.TabStop = true;
            this.radioButtonPar1OFF.Text = " OFF";
            this.radioButtonPar1OFF.UseVisualStyleBackColor = true;
            // 
            // groupBoxPar2
            // 
            this.groupBoxPar2.Controls.Add(this.radioButtonPar2ON);
            this.groupBoxPar2.Controls.Add(this.radioButtonPar2OFF);
            this.groupBoxPar2.Location = new System.Drawing.Point(146, 13);
            this.groupBoxPar2.Name = "groupBoxPar2";
            this.groupBoxPar2.Size = new System.Drawing.Size(56, 63);
            this.groupBoxPar2.TabIndex = 24;
            this.groupBoxPar2.TabStop = false;
            this.groupBoxPar2.Text = "Par2";
            // 
            // radioButtonPar2ON
            // 
            this.radioButtonPar2ON.AutoSize = true;
            this.radioButtonPar2ON.Location = new System.Drawing.Point(6, 19);
            this.radioButtonPar2ON.Name = "radioButtonPar2ON";
            this.radioButtonPar2ON.Size = new System.Drawing.Size(41, 17);
            this.radioButtonPar2ON.TabIndex = 2;
            this.radioButtonPar2ON.TabStop = true;
            this.radioButtonPar2ON.Text = "ON";
            this.radioButtonPar2ON.UseVisualStyleBackColor = true;
            // 
            // radioButtonPar2OFF
            // 
            this.radioButtonPar2OFF.AutoSize = true;
            this.radioButtonPar2OFF.Location = new System.Drawing.Point(6, 40);
            this.radioButtonPar2OFF.Name = "radioButtonPar2OFF";
            this.radioButtonPar2OFF.Size = new System.Drawing.Size(48, 17);
            this.radioButtonPar2OFF.TabIndex = 3;
            this.radioButtonPar2OFF.TabStop = true;
            this.radioButtonPar2OFF.Text = " OFF";
            this.radioButtonPar2OFF.UseVisualStyleBackColor = true;
            // 
            // buttonGetParameters
            // 
            this.buttonGetParameters.Location = new System.Drawing.Point(203, 91);
            this.buttonGetParameters.Name = "buttonGetParameters";
            this.buttonGetParameters.Size = new System.Drawing.Size(62, 22);
            this.buttonGetParameters.TabIndex = 9;
            this.buttonGetParameters.Text = "Leggi";
            this.buttonGetParameters.UseVisualStyleBackColor = true;
            this.buttonGetParameters.Click += new System.EventHandler(this.buttonGetParameters_Click);
            // 
            // numericUpDownParameters
            // 
            this.numericUpDownParameters.Location = new System.Drawing.Point(8, 94);
            this.numericUpDownParameters.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.numericUpDownParameters.Name = "numericUpDownParameters";
            this.numericUpDownParameters.Size = new System.Drawing.Size(43, 20);
            this.numericUpDownParameters.TabIndex = 8;
            this.numericUpDownParameters.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pictureBoxPlexa
            // 
            this.pictureBoxPlexa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxPlexa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxPlexa.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxPlexa.Image")));
            this.pictureBoxPlexa.Location = new System.Drawing.Point(560, 11);
            this.pictureBoxPlexa.Name = "pictureBoxPlexa";
            this.pictureBoxPlexa.Size = new System.Drawing.Size(167, 63);
            this.pictureBoxPlexa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxPlexa.TabIndex = 10;
            this.pictureBoxPlexa.TabStop = false;
            // 
            // pictureBoxDisconnect
            // 
            this.pictureBoxDisconnect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxDisconnect.Image = global::DemoPlexaNetK.Properties.Resources.ledRRed;
            this.pictureBoxDisconnect.InitialImage = null;
            this.pictureBoxDisconnect.Location = new System.Drawing.Point(418, 49);
            this.pictureBoxDisconnect.Name = "pictureBoxDisconnect";
            this.pictureBoxDisconnect.Size = new System.Drawing.Size(19, 19);
            this.pictureBoxDisconnect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxDisconnect.TabIndex = 9;
            this.pictureBoxDisconnect.TabStop = false;
            this.pictureBoxDisconnect.Visible = false;
            // 
            // pictureBoxConnect
            // 
            this.pictureBoxConnect.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxConnect.InitialImage = null;
            this.pictureBoxConnect.Location = new System.Drawing.Point(418, 15);
            this.pictureBoxConnect.Name = "pictureBoxConnect";
            this.pictureBoxConnect.Size = new System.Drawing.Size(19, 19);
            this.pictureBoxConnect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxConnect.TabIndex = 8;
            this.pictureBoxConnect.TabStop = false;
            this.pictureBoxConnect.Visible = false;
            // 
            // axPlexaNetKX1
            // 
            this.axPlexaNetKX1.Location = new System.Drawing.Point(445, 17);
            this.axPlexaNetKX1.Name = "axPlexaNetKX1";
            this.axPlexaNetKX1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axPlexaNetKX1.OcxState")));
            this.axPlexaNetKX1.Size = new System.Drawing.Size(103, 20);
            this.axPlexaNetKX1.TabIndex = 0;
            this.axPlexaNetKX1.OnDisplayRepeat += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnDisplayRepeatEventHandler(this.axPlexaNetKX1_OnDisplayRepeat);
            this.axPlexaNetKX1.OnNodeInfo += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnNodeInfoEventHandler(this.axPlexaNetKX1_OnNodeInfo);
            this.axPlexaNetKX1.OnPulserSent += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnPulserSentEventHandler(this.axPlexaNetKX1_OnPulserSent);
            this.axPlexaNetKX1.OnPulserRepeat += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnPulserRepeatEventHandler(this.axPlexaNetKX1_OnPulserRepeat);
            this.axPlexaNetKX1.OnDisplaySent += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnDisplaySentEventHandler(this.axPlexaNetKX1_OnDisplaySent);
            this.axPlexaNetKX1.OnDisconnect += new System.EventHandler(this.axPlexaNetKX1_OnDisconnect);
            this.axPlexaNetKX1.OnDisplayUpdate += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnDisplayUpdateEventHandler(this.axPlexaNetKX1_OnDisplayUpdate);
            this.axPlexaNetKX1.OnKeyEnter += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnKeyEnterEventHandler(this.axPlexaNetKX1_OnKeyEnter);
            this.axPlexaNetKX1.OnPulserUpdate += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnPulserUpdateEventHandler(this.axPlexaNetKX1_OnPulserUpdate);
            this.axPlexaNetKX1.OnNewNodeParameters += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnNewNodeParametersEventHandler(this.axPlexaNetKX1_OnNewNodeParameters);
            this.axPlexaNetKX1.OnLedsAndBuzzerUpdate += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnLedsAndBuzzerUpdateEventHandler(this.axPlexaNetKX1_OnLedsAndBuzzerUpdate);
            this.axPlexaNetKX1.OnDigitalLevelRead += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnDigitalLevelReadEventHandler(this.axPlexaNetKX1_OnDigitalLevelRead);
            this.axPlexaNetKX1.OnTamperChange += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnTamperChangeEventHandler(this.axPlexaNetKX1_OnTamperChange);
            this.axPlexaNetKX1.OnLedsAndBuzzerRepeat += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnLedsAndBuzzerRepeatEventHandler(this.axPlexaNetKX1_OnLedsAndBuzzerRepeat);
            this.axPlexaNetKX1.OnCompressedCodeEnter += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnCompressedCodeEnterEventHandler(this.axPlexaNetKX1_OnCompressedCodeEnter);
            this.axPlexaNetKX1.OnDisplayError += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnDisplayErrorEventHandler(this.axPlexaNetKX1_OnDisplayError);
            this.axPlexaNetKX1.OnPulserRead += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnPulserReadEventHandler(this.axPlexaNetKX1_OnPulserRead);
            this.axPlexaNetKX1.OnCodeUpdate += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnCodeUpdateEventHandler(this.axPlexaNetKX1_OnCodeUpdate);
            this.axPlexaNetKX1.OnCodeEnter += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnCodeEnterEventHandler(this.axPlexaNetKX1_OnCodeEnter);
            this.axPlexaNetKX1.OnDisplayRead += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnDisplayReadEventHandler(this.axPlexaNetKX1_OnDisplayRead);
            this.axPlexaNetKX1.OnPulserError += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnPulserErrorEventHandler(this.axPlexaNetKX1_OnPulserError);
            this.axPlexaNetKX1.OnCodeSent += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnCodeSentEventHandler(this.axPlexaNetKX1_OnCodeSent);
            this.axPlexaNetKX1.OnCodeRepeat += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnCodeRepeatEventHandler(this.axPlexaNetKX1_OnCodeRepeat);
            this.axPlexaNetKX1.OnAddressOnLine += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnAddressOnLineEventHandler(this.axPlexaNetKX1_OnAddressOnLine);
            this.axPlexaNetKX1.OnLedsAndBuzzerError += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnLedsAndBuzzerErrorEventHandler(this.axPlexaNetKX1_OnLedsAndBuzzerError);
            this.axPlexaNetKX1.OnAddressOffLine += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnAddressOffLineEventHandler(this.axPlexaNetKX1_OnAddressOffLine);
            this.axPlexaNetKX1.OnLedsAndBuzzerSent += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnLedsAndBuzzerSentEventHandler(this.axPlexaNetKX1_OnLedsAndBuzzerSent);
            this.axPlexaNetKX1.OnConnect += new System.EventHandler(this.axPlexaNetKX1_OnConnect);
            this.axPlexaNetKX1.OnCodeError += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnCodeErrorEventHandler(this.axPlexaNetKX1_OnCodeError);
            this.axPlexaNetKX1.OnError += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnErrorEventHandler(this.axPlexaNetKX1_OnError);
            // 
            // pictureBoxOnKeyEnter
            // 
            this.pictureBoxOnKeyEnter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxOnKeyEnter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxOnKeyEnter.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxOnKeyEnter.Location = new System.Drawing.Point(310, 28);
            this.pictureBoxOnKeyEnter.Name = "pictureBoxOnKeyEnter";
            this.pictureBoxOnKeyEnter.Size = new System.Drawing.Size(26, 18);
            this.pictureBoxOnKeyEnter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxOnKeyEnter.TabIndex = 27;
            this.pictureBoxOnKeyEnter.TabStop = false;
            // 
            // pictureBoxOnTamperChange
            // 
            this.pictureBoxOnTamperChange.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxOnTamperChange.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBoxOnTamperChange.Image = global::DemoPlexaNetK.Properties.Resources.ledRGreen;
            this.pictureBoxOnTamperChange.Location = new System.Drawing.Point(310, 27);
            this.pictureBoxOnTamperChange.Name = "pictureBoxOnTamperChange";
            this.pictureBoxOnTamperChange.Size = new System.Drawing.Size(26, 18);
            this.pictureBoxOnTamperChange.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxOnTamperChange.TabIndex = 29;
            this.pictureBoxOnTamperChange.TabStop = false;
            // 
            // FormDemoPlexaNetK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 738);
            this.Controls.Add(this.groupBoxParameters);
            this.Controls.Add(this.groupBoxCode);
            this.Controls.Add(this.groupBoxCodeComp);
            this.Controls.Add(this.textBoxErrorDesc);
            this.Controls.Add(this.checkBoxVerbose);
            this.Controls.Add(this.labelOutput);
            this.Controls.Add(this.pictureBoxPlexa);
            this.Controls.Add(this.labelInput);
            this.Controls.Add(this.groupBoxKeyEnter);
            this.Controls.Add(this.labelOnError);
            this.Controls.Add(this.groupBoxDigitalLevel);
            this.Controls.Add(this.groupBoxTamper);
            this.Controls.Add(this.textBoxVerbose);
            this.Controls.Add(this.groupBoxPulser);
            this.Controls.Add(this.pictureBoxDisconnect);
            this.Controls.Add(this.pictureBoxConnect);
            this.Controls.Add(this.groupBoxLed_Buzzer);
            this.Controls.Add(this.groupBoxInfoK);
            this.Controls.Add(this.groupBoxDisplay);
            this.Controls.Add(this.buttonDisconnect);
            this.Controls.Add(this.buttonConnect);
            this.Controls.Add(this.groupBoxKEInterface);
            this.Controls.Add(this.axPlexaNetKX1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(8, 530);
            this.Name = "FormDemoPlexaNetK";
            this.Padding = new System.Windows.Forms.Padding(3);
            this.Text = "DemoPlexaNetK";
            this.Load += new System.EventHandler(this.FormDemoPlexaNetK_Load);
            this.groupBoxKEInterface.ResumeLayout(false);
            this.groupBoxKEInterface.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSingleNode)).EndInit();
            this.groupBoxDisplay.ResumeLayout(false);
            this.groupBoxDisplay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnDisplayUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAddressDisplay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnDisplayRead)).EndInit();
            this.groupBoxInfoK.ResumeLayout(false);
            this.groupBoxInfoK.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnCodeEnter)).EndInit();
            this.groupBoxLed_Buzzer.ResumeLayout(false);
            this.groupBoxLed_Buzzer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnUpdateLed_Buzzer)).EndInit();
            this.groupBoxAdvancedLed.ResumeLayout(false);
            this.groupBoxAdvancedLed.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLedOk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLedFbk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLedAux)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCountLedOk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntervalLedOk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLedRdy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCountLedFbk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntervalLedFbk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCountLedAux)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntervalLedAux)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownValueBuzzer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntervalBuzzer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCountLedRdy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntervalLedRdy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAddressLed_Buzzer)).EndInit();
            this.groupBoxPulser.ResumeLayout(false);
            this.groupBoxPulser.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownResourcePulser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownValuePulser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnPulserUpdate)).EndInit();
            this.groupBoxAdvancedPulser.ResumeLayout(false);
            this.groupBoxAdvancedPulser.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCountPulser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIntervalPulser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnPulserRead)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAddressPulser)).EndInit();
            this.groupBoxTamper.ResumeLayout(false);
            this.groupBoxTamper.PerformLayout();
            this.groupBoxDigitalLevel.ResumeLayout(false);
            this.groupBoxDigitalLevel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownResourceDigitalLevel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAddressDigitalLevel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnDigitalLevel)).EndInit();
            this.groupBoxKeyEnter.ResumeLayout(false);
            this.groupBoxKeyEnter.PerformLayout();
            this.groupBoxCodeComp.ResumeLayout(false);
            this.groupBoxCodeComp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnCodeComp)).EndInit();
            this.groupBoxCode.ResumeLayout(false);
            this.groupBoxCode.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnCodeUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAddressCode)).EndInit();
            this.groupBoxParameters.ResumeLayout(false);
            this.groupBoxParameters.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnParameters)).EndInit();
            this.groupBoxPar4.ResumeLayout(false);
            this.groupBoxPar4.PerformLayout();
            this.groupBoxLOCREM.ResumeLayout(false);
            this.groupBoxLOCREM.PerformLayout();
            this.groupBoxPar3.ResumeLayout(false);
            this.groupBoxPar3.PerformLayout();
            this.groupBoxPar1.ResumeLayout(false);
            this.groupBoxPar1.PerformLayout();
            this.groupBoxPar2.ResumeLayout(false);
            this.groupBoxPar2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownParameters)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPlexa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDisconnect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxConnect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axPlexaNetKX1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnKeyEnter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOnTamperChange)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxPlexaNetKProj1.AxPlexaNetKX axPlexaNetKX1;
        private System.Windows.Forms.GroupBox groupBoxKEInterface;
        private System.Windows.Forms.RadioButton radioButtonPort;
        private System.Windows.Forms.TextBox textBoxIP;
        private System.Windows.Forms.RadioButton radioButtonServer;
        private System.Windows.Forms.ComboBox comboBoxCOM;
        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.Button buttonDisconnect;
        private System.Windows.Forms.GroupBox groupBoxDisplay;
        private System.Windows.Forms.Button buttonUpdateDisplay;
        private System.Windows.Forms.Button buttonReadDisplay;
        private System.Windows.Forms.Label labelRiga2;
        private System.Windows.Forms.Label labelRiga1;
        private System.Windows.Forms.TextBox textBoxRow2;
        private System.Windows.Forms.TextBox textBoxRow1;
        private System.Windows.Forms.GroupBox groupBoxInfoK;
        private System.Windows.Forms.TextBox textBoxTecnologyK;
        private System.Windows.Forms.TextBox textBoxResourceK;
        private System.Windows.Forms.TextBox textBoxValueK;
        private System.Windows.Forms.TextBox textBoxAddressK;
        private System.Windows.Forms.CheckBox checkBoxAcknowledge;
        private System.Windows.Forms.PictureBox pictureBoxOnDisplayUpdate;
        private System.Windows.Forms.PictureBox pictureBoxOnDisplayRead;
        private System.Windows.Forms.Label labelTecnologyK;
        private System.Windows.Forms.Label labelResourceK;
        private System.Windows.Forms.Label labelValueK;
        private System.Windows.Forms.Label labelAddressK;
        private System.Windows.Forms.GroupBox groupBoxLed_Buzzer;
        private System.Windows.Forms.Button buttonUpdate_Buzzer;
        private System.Windows.Forms.Button buttonUpdateLed;
        private System.Windows.Forms.NumericUpDown numericUpDownCountLedRdy;
        private System.Windows.Forms.NumericUpDown numericUpDownIntervalLedRdy;
        private System.Windows.Forms.NumericUpDown numericUpDownAddressLed_Buzzer;
        private System.Windows.Forms.GroupBox groupBoxAdvancedLed;
        private System.Windows.Forms.Label labelIntervalLed;
        private System.Windows.Forms.NumericUpDown numericUpDownValueBuzzer;
        private System.Windows.Forms.Label labelValueBuz;
        private System.Windows.Forms.NumericUpDown numericUpDownIntervalBuzzer;
        private System.Windows.Forms.Label labelCountLed;
        private System.Windows.Forms.Label labelAddressDisplay;
        private System.Windows.Forms.NumericUpDown numericUpDownAddressDisplay;
        private System.Windows.Forms.Label labelAddressLed_Buzzer;
        private System.Windows.Forms.GroupBox groupBoxPulser;
        private System.Windows.Forms.Label labelAddressPulser;
        private System.Windows.Forms.GroupBox groupBoxAdvancedPulser;
        private System.Windows.Forms.Label labelCountPulser;
        private System.Windows.Forms.Label labelIntervalPulser;
        private System.Windows.Forms.NumericUpDown numericUpDownCountPulser;
        private System.Windows.Forms.NumericUpDown numericUpDownIntervalPulser;
        private System.Windows.Forms.NumericUpDown numericUpDownAddressPulser;
        private System.Windows.Forms.Button buttonPulserRead;
        private System.Windows.Forms.Button buttonUpdatePulser;
        private System.Windows.Forms.PictureBox pictureBoxConnect;
        private System.Windows.Forms.PictureBox pictureBoxDisconnect;
        private System.Windows.Forms.Button buttonReadDigitalLevel;
        private System.Windows.Forms.PictureBox pictureBoxPlexa;
        private System.Windows.Forms.PictureBox pictureBoxOnCodeEnter;
        private System.Windows.Forms.PictureBox pictureBoxOnPulserUpdate;
        private System.Windows.Forms.PictureBox pictureBoxOnDigitalLevel;
        private System.Windows.Forms.PictureBox pictureBoxOnPulserRead;
        private System.Windows.Forms.PictureBox pictureBoxOnUpdateLed_Buzzer;
        private System.Windows.Forms.TextBox textBoxVerbose;
        private System.Windows.Forms.GroupBox groupBoxTamper;
        private System.Windows.Forms.Label labelOnError;
        private System.Windows.Forms.GroupBox groupBoxDigitalLevel;
        private System.Windows.Forms.NumericUpDown numericUpDownAddressDigitalLevel;
        private System.Windows.Forms.Label labelAddressDigitalLevel;
        private System.Windows.Forms.GroupBox groupBoxKeyEnter;
        private System.Windows.Forms.TextBox textBoxAddressTamper;
        private System.Windows.Forms.Label labelKeyEnterValue;
        private System.Windows.Forms.TextBox textBoxValueKey;
        private System.Windows.Forms.Label labelAddressKey;
        private System.Windows.Forms.TextBox textBoxAddressKey;
        private System.Windows.Forms.TextBox textBoxValueTamper;
        private System.Windows.Forms.Label labelAddressTamper;
        private System.Windows.Forms.Label labelValueTamper;
        private System.Windows.Forms.TextBox textBoxValueDigitalLevel;
        private System.Windows.Forms.Label labelValueDigitalLevel;
        private System.Windows.Forms.Label labelInput;
        private System.Windows.Forms.Label labelOutput;
        private System.Windows.Forms.Label labelValuePulser;
        private System.Windows.Forms.Label labelResourceReadDigitalLevel;
        private System.Windows.Forms.NumericUpDown numericUpDownValuePulser;
        private System.Windows.Forms.Label labelResourcePulser;
        private System.Windows.Forms.NumericUpDown numericUpDownResourceDigitalLevel;
        private System.Windows.Forms.NumericUpDown numericUpDownResourcePulser;
        private System.Windows.Forms.NumericUpDown numericUpDownCountLedOk;
        private System.Windows.Forms.NumericUpDown numericUpDownIntervalLedOk;
        private System.Windows.Forms.NumericUpDown numericUpDownCountLedFbk;
        private System.Windows.Forms.NumericUpDown numericUpDownIntervalLedFbk;
        private System.Windows.Forms.NumericUpDown numericUpDownCountLedAux;
        private System.Windows.Forms.NumericUpDown numericUpDownIntervalLedAux;
        private System.Windows.Forms.PictureBox pictureBoxLedRdy;
        private System.Windows.Forms.PictureBox pictureBoxLedAux;
        private System.Windows.Forms.PictureBox pictureBoxLedFbk;
        private System.Windows.Forms.PictureBox pictureBoxLedOk;
        private System.Windows.Forms.CheckBox checkBoxVerbose;
        private System.Windows.Forms.Timer timerOnAcknoledgeLed;
        private System.Windows.Forms.Label labelOnPulserSent;
        private System.Windows.Forms.TextBox textBoxErrorDesc;
        private System.Windows.Forms.Label labelOnDisplaySent;
        private System.Windows.Forms.Label labelOnLedAndBuzzerSent;
        private System.Windows.Forms.CheckBox checkBoxRow2;
        private System.Windows.Forms.CheckBox checkBoxRow1;
        private System.Windows.Forms.GroupBox groupBoxCodeComp;
        private System.Windows.Forms.TextBox textBoxCompValue2;
        private System.Windows.Forms.TextBox textBoxCompValue1;
        private System.Windows.Forms.TextBox textBoxCompNid;
        private System.Windows.Forms.Label labelValue2K;
        private System.Windows.Forms.Label labelValue1K;
        private System.Windows.Forms.Label labelCompAddress;
        private System.Windows.Forms.TextBox textBoxCompAddress;
        private System.Windows.Forms.Label labelCompTeck;
        private System.Windows.Forms.PictureBox pictureBoxOnCodeComp;
        private System.Windows.Forms.TextBox textBoxCompTecnology;
        private System.Windows.Forms.Label labelCompSid;
        private System.Windows.Forms.TextBox textBoxCompSid;
        private System.Windows.Forms.Label labelCompNid;
        private System.Windows.Forms.Label labelCompResourceK;
        private System.Windows.Forms.TextBox textBoxCompResource;
        private System.Windows.Forms.GroupBox groupBoxCode;
        private System.Windows.Forms.PictureBox pictureBoxOnCodeUpdate;
        private System.Windows.Forms.NumericUpDown numericUpDownAddressCode;
        private System.Windows.Forms.Button buttonUpdateCode;
        private System.Windows.Forms.TextBox textBoxCodeValue;
        private System.Windows.Forms.GroupBox groupBoxParameters;
        private System.Windows.Forms.RadioButton radioButtonPar3OFF;
        private System.Windows.Forms.RadioButton radioButtonPar3ON;
        private System.Windows.Forms.RadioButton radioButtonPar2OFF;
        private System.Windows.Forms.RadioButton radioButtonPar2ON;
        private System.Windows.Forms.RadioButton radioButtonPar1OFF;
        private System.Windows.Forms.RadioButton radioButtonPar1ON;
        private System.Windows.Forms.RadioButton radioButtonDSWRemote;
        private System.Windows.Forms.RadioButton radioButtonDSWLocal;
        private System.Windows.Forms.Button buttonGetParameters;
        private System.Windows.Forms.NumericUpDown numericUpDownParameters;
        private System.Windows.Forms.GroupBox groupBoxPar3;
        private System.Windows.Forms.GroupBox groupBoxPar2;
        private System.Windows.Forms.GroupBox groupBoxPar1;
        private System.Windows.Forms.GroupBox groupBoxLOCREM;
        private System.Windows.Forms.Label labelAddressCode;
        private System.Windows.Forms.Label labelOnCodeSent;
        private System.Windows.Forms.Label labelAddressParameters;
        private System.Windows.Forms.GroupBox groupBoxPar4;
        private System.Windows.Forms.RadioButton radioButtonPar4OFF;
        private System.Windows.Forms.RadioButton radioButtonPar4ON;
        private System.Windows.Forms.NumericUpDown numericUpDownSingleNode;
        private System.Windows.Forms.CheckBox checkBoxSingleNode;
        private System.Windows.Forms.PictureBox pictureBoxOnParameters;
        private System.Windows.Forms.CheckBox checkBoxRdy;
        private System.Windows.Forms.Label labelRdy;
        private System.Windows.Forms.CheckBox checkBoxOk;
        private System.Windows.Forms.Label labelOk;
        private System.Windows.Forms.CheckBox checkBoxFbk;
        private System.Windows.Forms.Label labelFbk;
        private System.Windows.Forms.CheckBox checkBoxAux;
        private System.Windows.Forms.Label labelAux;
        private System.Windows.Forms.PictureBox pictureBoxOnTamperChange;
        private System.Windows.Forms.PictureBox pictureBoxOnKeyEnter;
                
    }
}

