using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DemoPlexaNetK_C
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            axPlexaNetKX1.Server = textBoxIP.Text;
            axPlexaNetKX1.Port = "";
            //axPlexaNetKX1.Server = "";
            //axPlexaNetKX1.Port = "COM1:";
            axPlexaNetKX1.AcknowledgedMode = true;
            axPlexaNetKX1.Connect();
        }

        private void axPlexaNetKX1_OnConnect(object sender, EventArgs e)
        {
            buttonBeep.Enabled = true;
        }

        private void buttonBeep_Click(object sender, EventArgs e)
        {
            axPlexaNetKX1.UpdateLedsAndBuzzer(1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 5); 
        }

        private void axPlexaNetKX1_OnCodeEnter(object sender, AxPlexaNetKProj1.IPlexaNetKXEvents_OnCodeEnterEvent e)
        {
            textBoxCodeEnter.Text = e.value;
        }
    }
}