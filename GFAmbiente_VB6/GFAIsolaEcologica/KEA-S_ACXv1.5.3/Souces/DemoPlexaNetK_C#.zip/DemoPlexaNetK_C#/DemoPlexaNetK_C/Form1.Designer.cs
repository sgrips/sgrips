namespace DemoPlexaNetK_C
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.axPlexaNetKX1 = new AxPlexaNetKProj1.AxPlexaNetKX();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.textBoxIP = new System.Windows.Forms.TextBox();
            this.buttonBeep = new System.Windows.Forms.Button();
            this.textBoxCodeEnter = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.axPlexaNetKX1)).BeginInit();
            this.SuspendLayout();
            // 
            // axPlexaNetKX1
            // 
            this.axPlexaNetKX1.Location = new System.Drawing.Point(12, 238);
            this.axPlexaNetKX1.Name = "axPlexaNetKX1";
            this.axPlexaNetKX1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axPlexaNetKX1.OcxState")));
            this.axPlexaNetKX1.Size = new System.Drawing.Size(268, 23);
            this.axPlexaNetKX1.TabIndex = 0;
            this.axPlexaNetKX1.OnCodeEnter += new AxPlexaNetKProj1.IPlexaNetKXEvents_OnCodeEnterEventHandler(this.axPlexaNetKX1_OnCodeEnter);
            this.axPlexaNetKX1.OnConnect += new System.EventHandler(this.axPlexaNetKX1_OnConnect);
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(141, 12);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(75, 23);
            this.buttonConnect.TabIndex = 1;
            this.buttonConnect.Text = "Connect";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // textBoxIP
            // 
            this.textBoxIP.Location = new System.Drawing.Point(12, 14);
            this.textBoxIP.Name = "textBoxIP";
            this.textBoxIP.Size = new System.Drawing.Size(100, 20);
            this.textBoxIP.TabIndex = 2;
            this.textBoxIP.Text = "10.0.0.209";
            // 
            // buttonBeep
            // 
            this.buttonBeep.Enabled = false;
            this.buttonBeep.Location = new System.Drawing.Point(12, 87);
            this.buttonBeep.Name = "buttonBeep";
            this.buttonBeep.Size = new System.Drawing.Size(75, 23);
            this.buttonBeep.TabIndex = 3;
            this.buttonBeep.Text = "Beep";
            this.buttonBeep.UseVisualStyleBackColor = true;
            this.buttonBeep.Click += new System.EventHandler(this.buttonBeep_Click);
            // 
            // textBoxCodeEnter
            // 
            this.textBoxCodeEnter.Location = new System.Drawing.Point(12, 155);
            this.textBoxCodeEnter.Name = "textBoxCodeEnter";
            this.textBoxCodeEnter.Size = new System.Drawing.Size(268, 20);
            this.textBoxCodeEnter.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.textBoxCodeEnter);
            this.Controls.Add(this.buttonBeep);
            this.Controls.Add(this.textBoxIP);
            this.Controls.Add(this.buttonConnect);
            this.Controls.Add(this.axPlexaNetKX1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.axPlexaNetKX1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxPlexaNetKProj1.AxPlexaNetKX axPlexaNetKX1;
        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.TextBox textBoxIP;
        private System.Windows.Forms.Button buttonBeep;
        private System.Windows.Forms.TextBox textBoxCodeEnter;
    }
}

