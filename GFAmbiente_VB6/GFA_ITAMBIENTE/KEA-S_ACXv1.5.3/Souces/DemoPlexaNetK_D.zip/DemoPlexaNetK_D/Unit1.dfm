object Form1: TForm1
  Left = -2
  Top = 103
  Width = 870
  Height = 640
  Caption = 'Form1'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object PlexaNetKX1: TPlexaNetKX
    Left = 40
    Top = 288
    Width = 696
    Height = 134
    ParentColor = False
    ParentFont = False
    TabOrder = 0
    OnConnect = PlexaNetKX1Connect
    OnCodeEnter = PlexaNetKX1CodeEnter
    ControlData = {
      545046300B54506C6578614E65744B580A506C6578614E65744B58044C656674
      022803546F7003200105576964746803B8020648656967687403860007436170
      74696F6E060A506C6578614E65744B5805436F6C6F720709636C42746E466163
      650C466F6E742E43686172736574070F44454641554C545F434841525345540A
      466F6E742E436F6C6F72070C636C57696E646F77546578740B466F6E742E4865
      6967687402F509466F6E742E4E616D65060D4D532053616E732053657269660A
      466F6E742E5374796C650B000E4F6C644372656174654F72646572080D506978
      656C73506572496E636802600A54657874486569676874020D0000}
  end
  object EditIP: TEdit
    Left = 56
    Top = 48
    Width = 121
    Height = 21
    TabOrder = 1
    Text = '10.0.0.209'
  end
  object ButtonConnect: TButton
    Left = 224
    Top = 48
    Width = 75
    Height = 25
    Caption = 'Connect'
    TabOrder = 2
    OnClick = ButtonConnectClick
  end
  object ButtonBeep: TButton
    Left = 56
    Top = 128
    Width = 75
    Height = 25
    Caption = 'Beep'
    Enabled = False
    TabOrder = 3
    OnClick = ButtonBeepClick
  end
  object EditCodeEnter: TEdit
    Left = 64
    Top = 184
    Width = 593
    Height = 21
    TabOrder = 4
  end
end
