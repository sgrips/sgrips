unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, OleCtrls, PlexaNetKProj1_TLB;

type
  TForm1 = class(TForm)
    PlexaNetKX1: TPlexaNetKX;
    EditIP: TEdit;
    ButtonConnect: TButton;
    ButtonBeep: TButton;
    EditCodeEnter: TEdit;
    procedure ButtonConnectClick(Sender: TObject);
    procedure PlexaNetKX1Connect(Sender: TObject);
    procedure ButtonBeepClick(Sender: TObject);
    procedure PlexaNetKX1CodeEnter(ASender: TObject; Address, Resource,
      Technology: Integer; const Value: WideString);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

procedure TForm1.ButtonConnectClick(Sender: TObject);
begin
  PlexaNetKX1.Server := EditIP.Text;
  PlexaNetKX1.Port := '';
  //PlexaNetKX1.Server := '';
  //PlexaNetKX1.Port := 'COM1:';
  PlexaNetKX1.AcknowledgedMode := True;
  PlexaNetKX1.Connect;
end;

procedure TForm1.PlexaNetKX1Connect(Sender: TObject);
begin
  ButtonBeep.Enabled := True;
end;

procedure TForm1.ButtonBeepClick(Sender: TObject);
begin
  PlexaNetKX1.UpdateLedsAndBuzzer(1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 5);
end;

procedure TForm1.PlexaNetKX1CodeEnter(ASender: TObject; Address, Resource,
  Technology: Integer; const Value: WideString);
begin
  EditCodeEnter.Text := Value;
end;

end.
